<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <link rel="icon" href="/favicon.ico">
    <link href='/template/{@var:cms_config_tpl_dir}/css/app.css' rel='stylesheet'>
    <style>
        .play_btn>a {
            color: #fff;
            font-weight: bold;
            width: 100%;
            height: 100%;
            display: inline-block;
        }

        .video_info .play_video {
            text-align: center;
        }

        .video_info .play_video img {
            max-height: 6.5rem;
            min-height: 5rem;
            object-fit: cover;
        }

        .video_info .play_video a:after {
            content: "";
            background: url(/template/{@var:cms_config_tpl_dir}/images/play.png) center center no-repeat;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #00000040;
        }

        .list_play {
            display: flex;
            align-items: center;
        }

        .listtitle {
            height: 1rem;
        }

        .boximghf {
            margin-bottom: .2rem;
        }
    </style>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body>

{@include file:header}




            <div class="video video_info play_video">
            <div class="play_scroll">
                <div class="play_content">
                    <div class="play_title" style="margin: 10px 0;">{@name}</div>


<div style="text-align: left; color: #dbdbdb;font-size: 16px;">
{base64}【影片格式】：mp4<br>
【影片大小】：{@var:torrent_size}<br>
【影片时长】：{@var:torrent_duration}分钟<br>
【分辨率】：{@var:torrent_resolution}<br>
【影片预览】：<br>{/base64}
</div>
<div class="clearfix" style="margin: 0px;">
    {@var:torrent_capture}
</div>

<div style="clear: both;"></div>

<div class="download">
    <div class="hide_mobile">
        <div class="downbtn">
            <a href="{@var:torrent_file_url}" style="width: 100%;">{base64}下载种子{/base64}</a>
        </div>
    </div>
    <div class="downbtn">
        <a href="{@var:torrent_magnet}" style="width: 100%;">{base64}打开磁力{/base64}</a>
    </div>
    <div class="downbtn">
        <a onclick="copyText()" href="javascript:;" style="width: 100%;">{base64}复制磁力{/base64}</a>
    </div>
</div>

<div style="float: left; clear: both;"></div>
<div style="text-align: left;">

    <div class="hide_mobile" style="padding: 10px;">
        <a style="font-size: 16px; color:#dbdbdb ;" href='{@var:api_config_bt_client_pc_download_url}' target='_blank'>{@var:api_config_bt_client_pc_download_text}</a>
    </div>

    <div class="hide_pc" style="padding: 10px;">
        <a style="font-size: 16px; color:#dbdbdb ;" href='{@var:api_config_bt_client_mobile_download_url}'>{@var:api_config_bt_client_mobile_download_text}</a>
    </div>
</div>

<style type="text/css">
.download {
    display: flex;
    justify-content: center;
    color: white;

    margin-top: 20px;
    text-align: center;
    font-size: 20px;
}

.downbtn a  {
    color: white;
    width: 100%;
}

.downbtn {
    display: inline-block;
    background: #ff9903;
    color: white;
    margin: 0px 10px;
    padding: 0 10px;
    font-weight: bold;
}


</style>


<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }
  </script>

<style type="text/css">
   .wrapper2 {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;font-size: 1px;}
</style>

<div class="wrapper2">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>






                    
                </div>
            </div>

            </div>



            <div class="video  van-pull-refresh">
                <div class="van-pull-refresh__track">
                    <div class="theme_list play_list">
                        <div class="play_list_title">猜你喜欢</div>

                        <div class="list">
                            <div class="van-row">
{list type:bt mode:rand total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
    {/list}
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>




{@include file:footer}
</body>

</html>


