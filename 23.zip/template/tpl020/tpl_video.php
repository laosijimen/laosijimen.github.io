<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <link rel="icon" href="/favicon.ico">
    <link href='/template/{@var:cms_config_tpl_dir}/css/app.css' rel='stylesheet'>
    <style>
        .play_btn>a {
            color: #fff;
            font-weight: bold;
            width: 100%;
            height: 100%;
            display: inline-block;
        }

        .video_info .play_video {
            text-align: center;
        }

        .video_info .play_video img {
            max-height: 6.5rem;
            min-height: 5rem;
            object-fit: cover;
        }

        .video_info .play_video a:after {
            content: "";
            background: url(/template/{@var:cms_config_tpl_dir}/images/play.png) center center no-repeat;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #00000040;
        }

        .list_play {
            display: flex;
            align-items: center;
        }

        .listtitle {
            height: 1rem;
        }

        .boximghf {
            margin-bottom: .2rem;
        }
    </style>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body>

{@include file:header}




            <div class="video video_info play_video">
            <div class="play_scroll">
                <div class="play_content">
                    <div class="play_title" style="margin: 10px 0;">{@name}</div>
<video style="width:100%;max-height:720px;" class="player-box" id="video"  controls autoplay></video>
{@palyer_js}
                </div>
            </div>

            </div>



            <div class="video  van-pull-refresh">
                <div class="van-pull-refresh__track">
                    <div class="theme_list play_list">
                        <div class="play_list_title">猜你喜欢</div>

                        <div class="list">
                            <div class="van-row">
{list type:video mode:rand total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
    {/list}
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>




{@include file:footer}
</body>

</html>


