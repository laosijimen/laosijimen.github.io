<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>{@page_title}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <link href="/template/{@var:cms_config_tpl_dir}/css/main.min.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min2.2.4.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
    <style>
        .pagination ul {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .pagination ul li {
            display: inline;
        }

        .pagination ul li a {
            float: left;
            background-color: #ffffff !important;
            color: #4a545a !important;
            height: 32px;
            font-size: 22px;
            line-height: 32px;
            margin-bottom: 8px !important;
            margin-right: 8px !important;
            position: relative;
            display: inline-block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            min-width: 58px;
            margin: 0;
            padding: 0 16px;
            overflow: hidden;
            font-weight: 500;
            letter-spacing: .04em;
            white-space: nowrap;
            text-align: center;
            text-transform: uppercase;
            text-decoration: none;
            vertical-align: middle;
            background: 0 0;
            border: none;
            border-radius: 2px;
            outline: 0;
            cursor: pointer;
            -webkit-transition: all .2s cubic-bezier(.4, 0, .2, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), box-shadow .2s cubic-bezier(.4, 0, 1, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            will-change: box-shadow;
            zoom: 1;
            -webkit-user-drag: none;
        }

        .pagination ul a.dqy,
        .pagination ul a:hover {
            background-color: #37bf91 !important;
            color: #ffffff !important;
        }

        @media screen and (max-width: 48em) {
            .navbar {
                display: block;
            }

            .nav_left {
                width: 25%;
                float: left;
            }

            .navbar__logo {
                width: 50%;
                float: left;
            }

            .nav_right {
                float: right;
            }

            .logo__mark {
                line-height: 1.375em;
            }
        }

        @media (max-width: 30em) {
            .cards__item {
                width: 50%;
            }
        }
        }
    </style>
    {@common_head}
</head>

<body class="page finished loaded">


        {@include file:header}

        <main class="page__main">
            <div class="trailer">
                <div class="container container--big">
                    <div class="trailer__wrap">
                        <div class="trailer__player">
                            <div class="trailer__info">
                                <div class="heading">
                                    <div class="heading__item">
                                        <h1 class="heading__title">{@name}</h1>
                                    </div>
                                </div>




                                <div class="player">
                                    <div class="player__wrap">
                                        <div class="player-wrap">
                                                {base64}【影片格式】：mp4<br>
                                                【影片大小】：{@var:torrent_size}<br>
                                                【影片时长】：{@var:torrent_duration}分钟<br>
                                                【分辨率】：{@var:torrent_resolution}<br>
                                                【影片预览】：<br>{/base64}
                                                <div class="clearfix" style="margin: 20px; height: 100%;">
                                                    {@var:torrent_capture}
                                                </div>

                                                <div style="clear: both;"></div>

<div  style="   padding: 0 10px 10px;">
    <div class="trailer__col">
        <div class="btn-group">
            <div class="btn-group__item search_tags d hide_mobile" style="padding: 0 10px;">
                <a class="btn btn--primary btn--sm" href="{@var:torrent_file_url}">{base64}下载种子{/base64}</a>
            </div>

            <div class="btn-group__item search_tags d" style="padding: 0 10px;">
                <a class="btn btn--primary btn--sm" href="{@var:torrent_magnet}">{base64}打开磁力{/base64}</a>
            </div>
            <div class="btn-group__item search_tags d" style="padding: 0 10px;">
                <a class="btn btn--primary btn--sm" onclick="copyText()" href="javascript:;">{base64}复制磁力{/base64}</a>
            </div>
        </div>
    </div>
</div>
                                                



<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }
  </script>

<style type="text/css">
   .wrapper {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;}
</style>

<div class="wrapper">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>


                                        

                                                <div style="clear: both;"></div>


                    <div class="hide_mobile" style="padding-top: 40px;">
                      <a style="font-size: 16px; color: black;" href='{@var:api_config_bt_client_pc_download_url}' target='_blank'>{@var:api_config_bt_client_pc_download_text}</a>
                    </div>

                    <div class="hide_pc" style="padding-top: 40px;">
                      <a style="font-size: 16px; color: black;" href='{@var:api_config_bt_client_mobile_download_url}'>{@var:api_config_bt_client_mobile_download_text}</a>
                    </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>



                    <div class="heading">
                        <div class="heading__item">
                            <h1 class="heading__title">
                                最新視頻
                            </h1>
                        </div>
                    </div>




                    <div class="cards__list" data-items="true">





                        {list type:bt mode:rand total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}

                    </div>
                </div>
            </div>
        </main>
{@include file:footer}
</body>

</html>