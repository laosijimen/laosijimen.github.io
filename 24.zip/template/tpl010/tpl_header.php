    
    <div class="wrapper">
        <style>
            @media all and (min-width: 950px) {
                .menu {
                    width: 100%;
                    height: auto;
                }

                .menu li {
                    margin: 0px 5px 10px 0;
                }
            }

            .menu a {
                border-radius: 0;
            }

            .logo span.newurl {
                display: none;
            }

            .menu.active {
                height: auto;
            }
        </style>

{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow" style="width: 100%;" class="{_class}">
        <img src="{_image}" style="width: 100%;" class="{_class}"></a>
</div>
{/ad}


        <div class="header">




            <div class="logo"><a href="/">{@var:site_name}<span class="newurl" style="text-transform:uppercase;padding-left:10px;">rrl33.buzz</span></a></div>
            <div class="menu">
                <ul>


                    <li class=" "><a href="/"><i class="fa fa-home"></i> 网站首页</a></li>
                    {nav type:video no:v2 count:7}
                    <li class=" "><a href="{_class_link}"><i class="fa fa-play-circle"></i> {_class_name}</a></li>
                    {/nav}


                    {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                    <li class=" "><a href="{_class_link}"><i class="fa fa-play-circle"></i> {_class_name}</a></li>
                    {/nav}



                </ul>
            </div>
        </div>
        <style>
            .fenleilist {
                display: none;
            }

            @media screen and (max-width: 950px) {
                .fenleilist {
                    display: block;
                }
            }
        </style>
        <style>
            .fenleilist ul {
                display: grid;
                grid-template-columns: auto auto auto auto auto auto;
                padding: 2px
            }

            .fenleilist ul li {
                text-align: center;
                margin: 0px 8px 8px 8px;
                display: block;
            }

            .fenleilist ul li a {
                width: 100%;
                text-decoration: none;
                background-color: #fff;
                font-size: 26px;
                padding: 5px;
                /*border-radius:5px;*/
                display: inline-block;
            }

            .fenleilist ul li.mok a {
                background-color: rgb(227, 68, 73);
                color: rgb(255, 255, 255);
            }

            @media only screen and (max-width:1400px) {
                .fenleilist ul li a {
                    font-size: 26px;
                }

                .fenleilist ul {
                    grid-template-columns: auto auto auto auto auto;
                }
            }

            @media only screen and (max-width:750px) {
                .fenleilist ul li a {
                    font-size: 22px;
                }

                .fenleilist ul {
                    grid-template-columns: auto auto auto;
                }
            }
        </style>
        <div class="fenleilist">
            <ul style="padding:0;margin:20px 0 10px;">

                <li class="mok"><a href="/"><i class="fa fa-home"></i> 网站首页</a></li>
                {nav type:video no:v2 count:7}
                <li class=" "><a href="{_class_link}"><i class=""></i> {_class_name}</a></li>
                {/nav}


                {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                <li class=" "><a href="{_class_link}"><i class=""></i> {_class_name}</a></li>
                {/nav}


            </ul>
        </div>
        <style>
            .linklist ul {
                display: grid;
                grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto;
                padding: 2px
            }

            .linklist ul li {
                text-align: center;
                margin: 0px 8px 2px 8px;
                display: block;
            }

            .linklist ul li a {
                width: 100%;
                text-decoration: none;
                background-color: #181818;
                color: #fff;
                font-size: 18px;
                padding: 5px;
                border-radius: 0px;
                display: inline-block;
                white-space: nowrap;
            }

            @media only screen and (max-width:1400px) {
                .linklist ul li a {
                    font-size: 16px;
                }

                .linklist ul {
                    grid-template-columns: auto auto auto auto auto auto;
                }
            }

            @media only screen and (max-width:750px) {
                .linklist ul li a {
                    font-size: 14px;
                }

                .linklist ul {
                    grid-template-columns: auto auto auto;
                }
            }

            .linklist ul li:nth-child(20n) a {
                background: #FF3366;
            }

            .linklist ul li:nth-child(11n+1) a {
                background: #66CC00;
            }

            .linklist ul li:nth-child(20n+2) a {
                background: #33CCFF;
            }

            .linklist ul li:nth-child(20n+3) a {
                background: #ffab00;
            }

            .linklist ul li:nth-child(20n+4) a {
                background: #ff00f1;
            }

            .linklist ul li:nth-child(20n+5) a {
                background: #fb3939;
            }

            .linklist ul li:nth-child(20n+6) a {
                background: #ff0000;
            }

            .linklist ul li:nth-child(20n+7) a {
                background: #2b36ff;
            }

            .linklist ul li:nth-child(20n+8) a {
                background: #00a90a;
            }

            .linklist ul li:nth-child(20n+9) a {
                background: #00b523;
            }

            .linklist ul li:nth-child(10n+10) a {
                background: #FF3366;
            }

            .linklist ul li:nth-child(20n+11) a {
                background: #32CD32;
            }

            .linklist ul li:nth-child(20n+12) a {
                background: #4c4c4c;
            }

            .linklist ul li:nth-child(20n+13) a {
                background: #FFA500;
            }

            .linklist ul li:nth-child(20n+14) a {
                background: #FF7F50;
            }

            .linklist ul li:nth-child(20n+15) a {
                background: #696969;
            }

            .linklist ul li:nth-child(20n+16) a {
                background: #F08080;
            }

            .linklist ul li:nth-child(20n+17) a {
                background: #DEB887;
            }

            .linklist ul li:nth-child(20n+18) a {
                background: #F08080;
            }

            .linklist ul li:nth-child(20n+19) a {
                background: #3e9096;
            }

            .linklist ul li a.lan {
                background: #1e88e5;
            }

            .linklist ul li a.fen {
                background: #ff4081;
            }

            .linklist ul li a.bai {
                background: #fff;
                color: #000;
            }

            .linklist ul li a.huang {
                background: #fed223;
                color: #222;
            }

            .linklist ul li a.hong {
                background-color: rgb(227, 68, 73);
                color: rgb(255, 255, 255);
            }
        </style>


        <div class="sstags">
            <ul>

                {splite var:hot_torrent_tags}
                <li class=""><a class="" href="/search.php?content=b64{_var_b64}&type=2">{base64}{_var}{/base64}</a></li>
                {/splite}

            </ul>
        </div>



        <div class="search" style="height:50px;visibility: visible;top:auto;position: static;background-color:darkgray;">
            <form id="search-form">
                <div class="search-input">
                    <input id="search_input" class="placehdr" type="text" placeholder="请输入搜索关键词..." required="" minlength="2" maxlength="40">
                </div>
                <button type="submit" title="Search">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>
        <script>
            document.getElementById('search-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var keyword = document.getElementById('search_input').value;
                var cleanedKeyword = keyword.replace(/-+/g, '');
                if (cleanedKeyword === '') {
                    alert('请输入搜索关键词...');
                    e.preventDefault();
                } else {
                    var search_url = '/search.php?content=' + encodeURIComponent(cleanedKeyword);
                    window.location.href = search_url;
                }
            });
        </script>




        <h3 style="padding: 0;margin: 0 0 8px 8px;color: #fff"><span class="">友情链接</span></h3>
        <div class="linklist">
            <ul style="padding:0;margin: 0 0 10px;">                
                {link area:link_yqlj1}
                    <li class=""><a class="bai" href="{_url}" target="_blank" style="color:;" rel="nofollow">{base64}{_text}{/base64}</a></li>
                {/link}
            </ul>
        </div>
        <style>
            .sstags ul {
                margin-top: 14px;
                font-size: 0;
                overflow: hidden
            }

            .sstags ul li {
                display: inline-block;
                vertical-align: top;
                margin: 6px 3px 0 3px;
                list-style-type: none;
                overflow: hidden
            }

            .sstags ul a {
                border-radius: 15px;
                display: block;
                height: 30px;
                line-height: 30px;
                padding: 0 15px;
                font-size: 12px;
                background-color: rgb(255, 255, 255);
                color: rgb(105, 105, 105);
                text-decoration: none
            }

            .sstags ul a:hover {
                background-color: rgb(227, 68, 73);
                color: rgb(255, 255, 255)
            }
        </style>
