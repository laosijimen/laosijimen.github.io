<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="robots" content="index, follow" />
    <meta charset="UTF-8" />
    <meta name="referrer" content="always">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{@page_title}</title>
    <link media="all" href="/template/{@var:cms_config_tpl_dir}/css/autoptimize.css" rel="stylesheet">
    <link href="/template/{@var:cms_config_tpl_dir}/css/iconfont.css" rel="stylesheet">
    <style>
        @media (min-width: 768px) {
            .topo-menu ul a {
                display: block;
                padding: 0 10px;
                line-height: 42px;
                color: #fff;
                font-size: 18px;
                font-weight: 500;
                width: 122.01px;
                height: 42px;
                border-radius: 10px;
                text-align: center;
                font-size: 1rem;
            }

            .logo-nome {
                color: #fff;
                background-color: #161616;
                font-size: 26px;
                font-weight: 600;
                height: 40px;
                display: inline-block;
                padding: 10px 0px 0;
            }
        }

        .paginacao li a.dqy {
            color: #FF0000;
        }
    </style>
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body class="archive category category-porn category-58">

    {@include file:header}

    <div class="meio">
        <div class="container">
            
            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:video index:1}">{@class_name type:video index:1}
                </a>
            </h3>
            <div class="videos">
{list type:video index:1 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}" class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a>
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>




            
            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:video index:4}">{@class_name type:video index:4}
                </a>
            </h3>
            <div class="videos">
{list type:video index:4 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}"  class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a >
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>


            
            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:video index:3}">{@class_name type:video index:3}
                </a>
            </h3>
            <div class="videos">
{list type:video index:3 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}"  class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a >
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>






            
            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:video index:2}">{@class_name type:video index:2}
                </a>
            </h3>
            <div class="videos">
{list type:video index:2 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}"  class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a >
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>



            
            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:bt index:1}">{@class_name type:bt index:1}
                </a>
            </h3>
            <div class="videos">
{list type:bt index:1 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}"  class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a >
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>


            <h3><i class="iconfont icon-all"></i> 
            <a href="{@class_link type:bt index:2}">{@class_name type:bt index:2}
                </a>
            </h3>
            <div class="videos">
{list type:bt index:2 total:8 title_len:40}
                <div class="video">
                    <div class="video-thumb">
                        <a href="{_url}"  class="thumb">
                            <img width="352" height="198" src='/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg' data-src="{_pic}" class="lazyload">
                            <span class="video-play "></span>
                            <span class="video-preview"></span>
                            <span class="video-slider"></span>
                        </a>
                    </div>
                    <a >
                        <span class="video-titulo">{_title}</span>
                    </a>
                    <div class="clearfix"></div>
                </div>
{/list}
                <div class="clearfix">
                </div>
            </div>


    {@include file:footer}

    
</body>

</html>

