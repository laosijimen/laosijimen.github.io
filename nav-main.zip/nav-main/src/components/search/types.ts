// 开源项目，未经作者同意，不得以抄袭/复制代码/修改源代码版权信息。

export enum SearchType {
  All = 1,
  Title,
  Desc,
  Url,
  Current,
  Quick,
  Id,
  Tag,
  Class,
}
