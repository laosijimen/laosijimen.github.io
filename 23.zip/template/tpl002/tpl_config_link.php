<?php exit();?>
link_haozhan === 更多好站 === 位于栏目导航右侧