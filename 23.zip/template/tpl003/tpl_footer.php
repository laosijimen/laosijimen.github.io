<?php exit();?>
            <div class="footer">
                <div class="footer-wrap">
                    <p class="text">
                        {base64}{@var:bottom_info}{/base64}
                    <div class="txt">
                        {base64}
                        所有的影片皆从外部来源于网络收集。没有视频托管本服务器上。如果您有任何法律问题，请联系合适的视频所有者或主机的网站.你还可以与我们联系。
                        {/base64}
                    </div>
                <script src="/template/{@var:cms_config_tpl_dir}/js/main.min.js"></script>
            </div>
{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}