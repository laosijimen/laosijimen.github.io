    <div class="av_plus">

        <div class="content">


{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}

            
            <div class="top">
                <a href="/" class="logo"></a>
            </div>
            <div class="plus_heads">
                <div class="plus_head">
                    <a href="/">网站首页</a>
{nav type:video no:v2 count:7} 
                    <a href="{_class_link}" class="">{_class_name}</a>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
                    <a href="{_class_link}" class="">{_class_name}</a>
{/nav}
                </div>
            </div>

<!--             <div class="vip_youlian">
                <a class="jzhh" href="httn/"  style="color:#f66151;border:3px solid #f66151;">蓝导航</a>
                <a class="jzhh" href="https:/后行/"  style="color:#f66151;border:3px solid #f66151;">AV集市</a>
            </div>

            <div class="av-apps">
                <a href="httyn9j9v"  >
                    <img src="/template/{@var:cms_config_tpl_dir}/picture/68.gif"><br>
                    <span style="color:#ff3939; jzhh"></span>
                </a>
                <a href="/s/c"  >
                    <img src="/template/{@var:cms_config_tpl_dir}/picture/66.gif"><br>
                    <span style="color:#986a44; jzhh"></span>
                </a>
            </div>
 -->

            <div class="search">
                <form action="/search.php" accept-charset="UTF-8" method="get">
                    <input name="content" required placeholder="输入关键字.." autocomplete="off" value="" ">
                    <button type="submit">搜索</button>
                </form>
            </div>

            <div class="youlian">
                <div class="yl yl-vip" style="margin-top:10px;">
{link area:link1}
                    <a class="jzhh" href="{_url}"  style="background:#ff4646;" target="_blank">{base64}{_text}{/base64}</a>
{/link}


                </div>
            </div>


        <div class="tags">
{splite var:search_tags_torrent}
<a href="/search.php?content=b64{_var_b64}&type=2" class="tag" >{base64}{_var}{/base64}</a>
{/splite}
        </div>

            

        </div>

