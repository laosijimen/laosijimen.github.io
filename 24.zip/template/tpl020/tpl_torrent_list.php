<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <link rel="icon" href="/favicon.ico">
    <link href='/template/{@var:cms_config_tpl_dir}/css/app.css' rel='stylesheet'>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body>
{@include file:header}


            <div class="van-pull-refresh">
                <div class="van-pull-refresh__track">
                    <div class="theme_list">
                        <div class="list-title">
                            <p>{@class_name} - 共 [<span style="color:#f90;">{@class_total}</span>] 部</p>
                        </div>

                        <div class="list">
                            <div class="van-row">
    {list type:bt mode:list title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
    {/list}
                            </div>
                        </div>

                        <div class="el-pagination is-background" style="padding: 15px 0;">
                            {link_first}<a href="{_url}"><button type='button' class='btn-prev'>首页</button></a>{/link_first}
                            <ul class="el-pager">

{links_pre max:3}
                                <a href="{_url}">
                                    <li class="number ">{_page_no}</li>
                                </a>

{/links_pre}



                                <a href="javascript:;">
                                    <li class="number active">{@page_cur}</li>
                                </a>


{links_next max:3}
                                <a href="{_url}">
                                    <li class="number ">{_page_no}</li>
                                </a>
{/links_next}


                            </ul>

                            {link_last}<a href="{_url}" class='pageitem pagenext'><button type='button' class='btn-next'>尾页</button></a>{/link_last}
                            

<!--                             <div class="el-pagination__jump">
                                前往
                                <div class="el-input el-pagination__editor is-in-pagination">
                                    <input id="page" type="number" autocomplete="off" min="1" max="3" class="el-input__inner page_input">
                                </div>
                                页
                            </div>
                            <button type="button" class="btn-next page-go">GO</button>
                            <div style="color: #bababa;">共{@page_total}页</div> -->
                        </div>
            <script>
                document.querySelectorAll(".list_type_btn a").forEach(function(btn) {
                    btn.addEventListener("click", function() {
                        document.querySelectorAll(".list_type_btn a").forEach(function(elem) {
                            elem.classList.remove("activeBtn");
                        });
                        this.classList.add("activeBtn");
                    });
                });
                document.querySelector(".page-go").addEventListener("click", function() {
                    var page = document.querySelector("#page").value;
                    if (page > 0 && page !== '') {
                        window.location.href = "/list.php?id={@var:raw_class_id}&page=" + page;
                    } else {
                        alert("请输入页数");
                    }
                });
            </script>

                    </div>
                </div>
            </div>
        </div>

{@include file:footer}
</body>

</html>