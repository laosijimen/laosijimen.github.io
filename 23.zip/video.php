<?php
$error_msg = '';

if(empty($_GET['id'])){
    $error_msg = '内容ID缺失';
}else{
    $raw_video_id = $_GET['id'];
    if(preg_match("#[^\d]#", $raw_video_id)){
        $error_msg = '内容ID不合法';
    }    
}

unset($_GET);
unset($_POST);
unset($_COOKIE);

define('INC', true);
include dirname(__FILE__)."/common.php";

if(!empty($error_msg)){
    js_jump("{$error_msg}。 即将返回首页", '/', 3, '404');
}

if($cms_config_rewrite_on == 'on2'){
    if($_SERVER["REQUEST_URI"] != get_uri('video', $raw_video_id)){
        js_jump();
    }
}

$this_content_type_id = 1;

list($video_source_id, $site_id) = splite_id($raw_video_id, 2);

$res = $sqlite_video_db->querySingle("SELECT * FROM video WHERE source_id={$video_source_id} and site_id={$site_id}", true);
if(empty($res)){
    js_jump("内容ID不存在。 即将返回首页(source_id:{$video_source_id}, site_id:{$site_id}, type_id:{$this_content_type_id})", '/', 3, '404');
}

$this_title = $res['title'];
$this_m3u8 = $res['m3u8'];
$this_class_id = $class_id = $res['class_id'];
$this_site_id = $site_id;

$this_class_name = $video_class_map_array[$site_id]['class'][$class_id];

//$tpl_html = file_get_contents_x("template/$cms_config_tpl_dir/tpl_video.php");
$tpl_html = load_tpl('tpl_video.php');

$page_title = $this_title;

include $base_dir . "/module_parse_tpl.php";

if($cms_config_encode_word == 'on3'){
    $tpl_html = encode_html($tpl_html);
}
echo $tpl_html;

if(!empty($cache_file_path)){
    cache_end($cache_file_path);
}