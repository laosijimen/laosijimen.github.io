    <div class="listbox2" style="margin-top:10px;">
{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow" style="width: 100%;" class="{_class}">
        <img src="{_image}" style="width: 100%;" class="{_class}"></a>
</div>
{/ad}
</div>
    
    <div class="header-b">
        <div class="header">
            <a href="/">{@site_name}</a>
        </div>
    </div>
    <div class="listbox" style="margin-top: 10px;box-shadow: 0 0 20px #a5a5a5;background: #000;">
        <div class="taglist">
            <a class="" href="/">网站首页</a>
            


                    {nav type:video no:v2 count:8}
                    <a href="{_class_link}" rel="nofollow">{_class_name}</a>
                    {/nav}


                    {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                    <a href="{_class_link}" rel="nofollow">{_class_name}</a>
                    {/nav}



        </div>
        <div class="searchbox" style="">
            <form class="searchform" action="/search.php" method="get">
                <input type="text" placeholder="站内搜索.." name="content">
                <button type="submit">搜索</button>
            </form>
        </div>
    </div>
    <style>
        .search_tags {
            background-color: #000;
            width: 80%;
            overflow: hidden;
            display: block;
            margin: 0px auto;
        }

        .search_tags .search_tags_list {
            padding: 15px;
        }

        .search_tags .search_tags_list a {
            background-color: #eee;
            color: #333;
            padding: 5px 15px;
            /*margin-right:5px;*/
            border-radius: 5px;
            display: inline-block;
            margin-bottom: 3px;
            text-decoration: none;
        }

        .search_tags .search_tags_list a:hover {
            color: white;
            background: linear-gradient(to right, #ff9900 0, #ff9f16 100%)
        }

        @media screen and (max-width: 767px) {
            .search_tags {
                width: 95%;
            }

            /*.search_tags .search_tags_list a{width: 24.3%;float: left;padding: 5px 0px;font-size: 13px;}*/
        }
    </style>
    <div class="search_tags" style="margin-top:0px;">
        <div class="search_tags_list">
{splite var:search_tags_torrent}
 <a href="/search.php?content=b64{_var_b64}&type=2" rel="nofollow" target="_blank" style="margin-right: 5px;">{base64}{_var}{/base64}</a>
{/splite}
        </div>
    </div>
    <style>
        /**APP**/
        .applist {
            width: 80%;
            margin: 0 auto;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 0 10px #ddd;
        }

        .applist ul {
            margin: 0;
            padding: 15px;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            overflow: hidden;
        }

        .applist ul li {
            display: inline-block;
            width: 8.333333333333333%;
            float: left;
            text-align: center;
            padding: 5px 0;
            font-size: 14px;
            line-height: 26px;
            border-radius: 13px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            transition: .2s;
            position: relative;
        }

        .applist ul li.cu {
            font-weight: 900;
        }

        .applist ul li a {
            text-decoration: none;
        }

        .applist ul li img {
            display: block;
            width: 66px;
            height: 66px;
            margin: 4px auto;
            border-radius: 12px;
        }

        .applist ul li i {
            position: absolute;
            top: 5px;
            left: 50%;
            margin-left: 22px;
        }

        .applist ul li:hover {
            background: #f80
        }

        @media(max-width:767px) {
            .applist {
                width: 95%;
            }
        }

        @media screen and (max-width:1460px) {
            .applist ul li {
                width: 9.090909090909091%;
            }
        }

        @media screen and (max-width:1300px) {
            .applist ul li {
                width: 10%;
            }

            .applist ul li img {
                width: 64px;
                height: 64px;
            }
        }

        @media screen and (max-width:1100px) {
            .applist ul li {
                width: 12.5%;
            }

            .applist ul li img {
                width: 60px;
                height: 60px;
            }
        }

        @media screen and (max-width:950px) {
            .applist ul li {
                width: 14.2857%;
            }
        }

        @media screen and (max-width:800px) {
            .applist ul li img {
                width: 56px;
                height: 56px;
            }
        }

        @media screen and (max-width:680px) {
            .applist ul li img {
                width: 52px;
                height: 52px;
            }
        }

        @media screen and (max-width:520px) {
            .applist {
                min-height: 100px;
            }

            .applist ul li {
                width: 25%;
            }

            .applist ul li img {
                width: 52px;
                height: 52px;
            }
        }
    </style>
<!--     <div class="applist" style="margin-top: 10px;box-shadow: 0 0 20px #a5a5a5;">
        <ul>

            <li class="" title="顶级色站榜">
                <a data-id="1548" href="" target="_blank" rel="nofollow" style="color: #000;">
                    <img class="lazy" data-original="/template/{@var:cms_config_tpl_dir}/picture/161926721.png" src="/style/gif.svg">顶级色站榜</a>
            </li>
            <li class="" title="逗妇乳">
                <a data-id="1552" href="" target="_blank" rel="nofollow" style="color: #000;">
                    <img class="lazy" data-original="/template/{@var:cms_config_tpl_dir}/picture/114846341.ico" src="/style/gif.svg">逗妇乳</a>
            </li>
        </ul>
    </div> -->
    <style>
        .zztj {
            width: 80%;
            overflow: hidden;
            display: block;
            /*box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);*/
            margin: 0px auto;
        }

        .zztj a {
            padding: 5px 10px;
            float: none;
            border-radius: 5px;
            text-align: center;
            font-size: 16px;
            color: #fff;
            display: inline-block;
            background-color: #000;
            margin: 1px;
            transition-duration: .3s;
            text-decoration: none;
        }

        .zztj a:nth-child(8n-7) {
            background: #8A9B0F
        }

        .zztj a:nth-child(8n-6) {
            background: #EB6841
        }

        .zztj a:nth-child(8n-5) {
            background: #3FB8AF
        }

        .zztj a:nth-child(8n-4) {
            background: #1aaf41
        }

        .zztj a:nth-child(8n-3) {
            background: #FC9D9A
        }

        .zztj a:nth-child(8n-2) {
            background: #EDC951
        }

        .zztj a:nth-child(8n-1) {
            background: #9d5656
        }

        .zztj a:nth-child(8n) {
            background: #83AF9B
        }

        .zztj a:first-child {
            background: #036564
        }

        .zztj a:last-child {
            background: #3299BB
        }

        .zztj a:hover {
            background: #000;
            color: #FFF
        }

        @media screen and (max-width: 767px) {
            .zztj {
                width: 95%;
            }

            .zztj a {
                width: 24.3%;
                float: left;
                padding: 5px 0px;
                font-size: 13px;
            }
        }
    </style>
    <div class="zztj">
        <div class="">
            <h1 style="font-size: 18px;border-bottom: 3px solid #f80;padding: 3px 10px;color: #f80;line-height: 28px;text-align: center;">推荐好站</h1>
        </div>
{link area:link_tjhz}
<a data-id="1548" href="{_url}" target="_blank" rel="nofollow" class="dh">{base64}{_text}{/base64}</a>
{/link}
    </div>
    <style>
        .hzhb {
            width: 80%;
            overflow: hidden;
            display: block;
            /*box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);*/
            margin: 0px auto;
        }

        .hzhblist a {
            background-color: #000;
            color: #fff;
            padding: 5px 15px;
            margin-right: 5px;
            border-radius: 5px;
            display: inline-block;
            text-decoration: none;
            margin-bottom: 3px;
            text-align: center;
        }

        .hzhblist a:hover {
            background: #f80;
        }

        @media screen and (max-width: 767px) {
            .hzhb {
                width: 95%;
            }

            .hzhblist a {
                width: 24.4%;
                padding: 5px 0px;
                float: left;
                font-size: 13px;
                margin: 1px;
            }
        }
    </style>
<!--     <div class="hzhb">
        <div class="">
            <h1 style="font-size: 18px;border-bottom: 3px solid #f80;padding: 3px 10px;color: #f80;line-height: 28px;text-align: center;">合作伙伴</h1>
        </div>
        <div class="hzhblist">
            <a data-id="1613" href="" target="_blank" rel="nofollow" class="dh">超级入口</a>
            <a data-id="1642" href="" target="_blank" rel="nofollow" class="dh">色色研究所</a>
        </div>
    </div> -->