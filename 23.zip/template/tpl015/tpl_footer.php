




<!--                 <h3>大家都在搜</h3>
                <div class="linklist">
                    <li><a class="size-3" href="">绘</a></li>
                    <li><a class="size-3" href="">真心话大冒险</a></li>
                </div> -->
<!--                 <div style="width: 100%; text-align:center; margin-left: auto; margin-right: auto">
                    <h3>推荐导航</h3>
                    <div class="grid-container">
                        <div class="grid-item d" style="background: #;">
                            <a href="" data-id="8139"  style="color:;">帝王会所</a>
                        </div>
                        <div class="grid-item d" style="background: #;">
                            <a href="" data-id="8151"  style="color:;">蜜桃导航</a>
                        </div>
                    </div>
                </div>
 -->            </div>
        </main>
        <footer class="footer">
            <div class="container">
                <a class="logo" href="/">{@site_name}</a>
                <div class="copyright">
                    <div>TG：</div>
                </div>
                <div class="disclaimer">We encourage you to report illegal or copyrighted content directly to us. all models displayed are 18+ years of age. Thank you!</div>
            </div>
        </footer>
    </div>
    <script src="/template/{@var:cms_config_tpl_dir}/js/validator.min.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/scripts.js"></script>
    <script type='text/javascript' src='/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.js'></script>
    <script type="text/javascript">
        $(function() {
            $("img.lazy").lazyload();
        });
    </script>
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/line-awesome.min.css">
    <div style="display:none">
    </div>


{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}