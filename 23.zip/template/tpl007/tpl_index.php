<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <title>性事可乐</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js" type="application/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
    <link href="/template/{@var:cms_config_tpl_dir}/css/html.css" rel="stylesheet" type="text/css" />
    <link href="/template/{@var:cms_config_tpl_dir}/css/style.css" rel="stylesheet" type="text/css" />
    <script></script>
    <style>
        #dplayer button {
            border-color: #000 !important;
            background-color: #000 !important;
        }

        #dplayer .dplayer-menu,
        #dplayer .dplayer-menu-show {
            display: none !important;
        }

        .pages ul a.dqy,
        .pages ul a.syy,
        .pages ul a.xyy {
            border-color: #F3ACBD !important;
            background-color: #F3ACBD !important;
            color: #fff;
        }

        #site-navigation>ul>li>a {
            padding: 0 0.5em;
        }
    </style>
    {@common_head}
</head>

<body class="home blog wp-embed-responsive hfeed">
    <div id="page">

        {@include file:header}


        <div id="content" class="site-content row">
            <div id="primary" class="content-area ">
                <main id="main" class="site-main " role="main">
                    <header class="page-header">
                        <h2 class="widget-title">{base64}{@class_name type:video index:1}{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:video index:1 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>


                    <header class="page-header">
                        <h2 class="widget-title">{base64}{@class_name type:video index:4}{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:video index:4 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>



                    <header class="page-header">
                        <h2 class="widget-title">{base64}{@class_name type:video index:3}{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:video index:3 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>




                    <header class="page-header">
                        <h2 class="widget-title">{base64}{@class_name type:video index:2}{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:video index:2 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>





                    <header class="page-header">
                        <h2 class="widget-title">{base64}日本磁力{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:bt index:2 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>




                    <header class="page-header">
                        <h2 class="widget-title">{base64}国产磁力{/base64}</h2>
                    </header>
                    <div class="videos-list">
                        {list type:bt index:1 total:8 title_len:24}
                        <article class="loop-video thumb-block full-width post-151135 post type-post status-publish format-standard has-post-thumbnail hentry category-amateur ">
                            <a href="{_url}">
                                <div class="post-thumbnail">
                                    <div class="post-thumbnail-container">
                                        <img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}">
                                    </div>
                                </div>
                                <header class="entry-header"><span>{_title}</span></header>
                            </a>
                        </article>
                        {/list}
                    </div>
                    <div class="clear"></div>
                </main>
            </div>
        </div>


        {@include file:footer}



</body>

</html>