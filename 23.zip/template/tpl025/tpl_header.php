    <div class="content">
        <div class="container">


{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}
            
            <div class="stui-header__top clearfix" style="position: relative;height: 60px;padding: 0 5px;">
                <div class="stui-header__logo" style="margin: 1px 0 0;padding: 0;float: left;">
                    <a href="/" >
                        <img style="max-height: 40px;margin-top: 10px;" src="/template/{@var:cms_config_tpl_dir}/picture/8b297c8ea99142fe42b7e9ba1fdd0654.jpg" ></a>
                </div>
                <div class="stui-header__search" style="float: none;width: auto;margin: 0;position: absolute;top: 15px;right: 10px;left: 168px;">
                    <form id="search" name="search" method="get" action="/index.php/vod/search.html" onsubmit="return qrsearch();">
                        <input type="text" id="wd" name="wd" class="mac_wd form-control" value="" placeholder="请输入关键词..." style="display: block;width: 100%;height: 35px;padding: 6px 45px 6px 10px;font-size: 12px;line-height: 32px;border-radius: 5px;background-color: #f5f5f5;color: #999;border: 0;">
                        <button class="submit" id="searchbutton" type="submit" name="submit" style="display: block;position: absolute;top: 0;right: 0;width: 35px;height: 35px;border: 0;cursor: pointer;background: url(/template/{@var:cms_config_tpl_dir}/images/icon_seacrh.png) center no-repeat;background-color: #ff3366;border-radius: 0px 5px 5px 0px;">
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
        <div class="content">
            <div class="container">
                <!--
                <div class="appel">
                     <div class="gongago">
                        <p class="gongago_p">
                            <b>
                                <font id="blink">公告：网址更新频繁，点击收藏！</font>
                            </b><a class="fuzhi" href="javascript:void(0);" onclick="copyLink()">点击收藏</a>
                        </p>
                    </div>

                    <script type="text/javascript">
                        function copyLink() {
                            var e = document.getElementById("copy");
                            e.select(); // 选择对象
                            document.execCommand("Copy"); // 执行浏览器复制命令
                            alert("网址复制成功！\n\n\n请粘贴到微信/QQ或者备忘录里。\n" +
                                "线路域名经常被屏蔽，请务必保存回家地址。\n\n如果您觉得本站还不错，请粘贴发送给好友。\n感谢～");
                        }
                    </script>
                    <script language="javascript">
                        function changeColor() {
                            var color = "#fff000|#2fff00|#FF0066|#00f3ff";
                            color = color.split("|");
                            document.getElementById("blink").style.color = color[parseInt(Math.random() * color.length)];
                        }
                        setInterval("changeColor()", 100);
                    </script>
                    <style>
                        textarea {
                            position: absolute;
                            top: 0;
                            left: 0;
                            opacity: 0;
                            z-index: -10;
                        }

                        .fuzhi {
                            background-color: #fff000;
                            /*border: 1px solid rgb(244, 244, 244);*/
                            height: 20px;
                            line-height: 20px;
                            text-align: center;
                            color: #000000;
                            padding: 2px 5px 2px 5px;
                            border-radius: 10px;
                            cursor: pointer;
                            text-decoration: none;
                        }

                        .fuzhi a:have {
                            background-color: #00000;
                            /*border: 1px solid rgb(244, 244, 244);*/
                            height: 20px;
                            line-height: 20px;
                            text-align: center;
                            color: #000000;
                            padding: 2px 5px 2px 5px;
                            border-radius: 10px;
                            cursor: pointer;
                            text-decoration: none;
                        }

                        .gonggao {
                            display: flex;
                            justify-content: space-between;
                            flex-wrap: wrap;
                            flex-direction: row;
                        }

                        .gongago_p {
                            padding: 5px;
                            text-align: center;
                        }
                    </style>
                    <textarea id="copy">备用网址www.qssf2.xyz,www.qssf3.xyz</textarea>
                </div>
 -->
                <div class="appel">
                    <div id="youmu" class="youmu-app">
                        <div class="area">

                            <dl class="first">
                                <dt><a href="/">在线1区</a></dt>
{nav type:video no:4 count:8} 
                                <dd><a href="{_class_link}">{_class_name}</a></dd>
{/nav}
                            </dl>


                            <dl class="first">
                                <dt><a href="/">在线2区</a></dt>
{nav type:video no:2 count:8} 
                                <dd><a href="{_class_link}">{_class_name}</a></dd>
{/nav}
                            </dl>
                            <dl class="first">
                                <dt><a href="/">在线3区</a></dt>
{nav type:video no:1 count:8} 
                                <dd><a href="{_class_link}">{_class_name}</a></dd>
{/nav}
                            </dl>


                            <dl class="first">
                                <dt><a href="/">在线4区</a></dt>
{nav type:video no:3 count:8} 
                                <dd><a href="{_class_link}">{_class_name}</a></dd>
{/nav}
                            </dl>



                            <dl class="first">
                                <dt><a href="/">下载1区</a></dt>
{nav type:bt no:1 count:8} 
                                <dd><a href="{_class_link}">{_class_name}</a></dd>
{/nav}
                            </dl>



                        </div>
                    </div>
                </div>

                <div class="appel">
                    <style>
                        .txtgg {
                            width: 100%;
                            overflow: hidden;
                            display: block;
                            box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .05);
                        }

                        .txtgg a {
                            width: 16.4%;
                            float: left;
                            border-radius: 3px;
                            line-height: 30px;
                            height: 30px;
                            text-align: center;
                            font-size: 14px;
                            color: #fff;
                            display: inline-block;
                            background-color: rgb(255, 153, 159);
                            margin: 1px;
                            transition-duration: .3s;
                        }

                        .txtgg a:nth-child(1) {
                            background-color: #ff00f1;
                        }

                        .txtgg a:nth-child(2) {
                            background-color: #66CC00;
                        }

                        .txtgg a:nth-child(3) {
                            background-color: #33CCFF;
                        }

                        .txtgg a:nth-child(4) {
                            background-color: #ffab00;
                        }

                        .txtgg a:nth-child(5) {
                            background-color: #ff00f1;
                        }

                        .txtgg a:nth-child(6) {
                            background-color: #fb3939;
                        }

                        .txtgg a:nth-child(7) {
                            background-color: #ff0000;
                        }

                        .txtgg a:nth-child(8) {
                            background-color: #2b36ff;
                        }

                        .txtgg a:nth-child(9) {
                            background-color: #00a90a;
                        }

                        .txtgg a:nth-child(10) {
                            background-color: #00b523;
                        }

                        .txtgg a:nth-child(11) {
                            background-color: #ff0040;
                        }

                        .txtgg a:nth-child(12) {
                            background-color: #ff7c00;
                        }

                        .txtgg a:nth-child(13) {
                            background-color: #006c82;
                        }

                        .txtgg a:nth-child(14) {
                            background-color: #77674b;
                        }

                        .txtgg a:nth-child(15) {
                            background-color: #996699;
                        }

                        .txtgg a:nth-child(16) {
                            background-color: #666666;
                        }

                        .txtgg a:nth-child(17) {
                            background-color: #006699;
                        }

                        .txtgg a:nth-child(18) {
                            background-color: #993333;
                        }

                        .txtgg a:nth-child(19) {
                            background-color: #993333;
                        }

                        .txtgg a:nth-child(20) {
                            background-color: #333300;
                        }

                        .txtgg a:nth-child(21) {
                            background-color: #663366;
                        }

                        .txtgg a:nth-child(22) {
                            background-color: #003300;
                        }

                        .txtgg a:nth-child(23) {
                            background-color: #003366;
                        }

                        .txtgg a:nth-child(24) {
                            background-color: #996699;
                        }

                        .txtgg a:nth-child(25) {
                            background-color: #666666;
                        }

                        .txtgg a:nth-child(26) {
                            background-color: #006699;
                        }

                        .txtgg a:nth-child(27) {
                            background-color: #993333;
                        }

                        .txtgg a:nth-child(28) {
                            background-color: #6593b7;
                        }

                        .txtgg a:nth-child(29) {
                            background-color: #96593e;
                        }

                        .txtgg a:nth-child(30) {
                            background-color: #3e9096;
                        }

                        .txtgg a:hover {
                            background: #DC3545;
                            color: #FFF
                        }

                        @media screen and (max-width: 1000px) {
                            .txtgg a {
                                width: 32.75%;
                                float: left;
                                border-radius: 3px;
                                line-height: 30px;
                                height: 30px;
                                text-align: center;
                                font-size: 13px;
                                color: #fff;
                                display: inline-block;
                                background-color: rgb(255, 153, 159);
                                margin: 1px;
                                transition-duration: .3s;
                            }
                        }
                    </style>
                    <div class='txtgg'>
{link area:link_top}
                        <a href="{_url}"   rel='nofollow' class='dh' style='text-decoration: none'>{base64}{_text}{/base64}</a>
{/link}


                    </div>

                </div>

                <div class="appel">
<!-- 

                    <div class="appel clearfix">
                        <div class="appel-main">
                            <div class="appel-heading clearfix">
                                <h3 class="appel-title">友情链接</h3>
                            </div>
                            <div class="detail-content tab-content ff-playurl-tab" id="detail-content">
                                <ul class="detail-play-list clearfix tab-pane ff-playurl ff-playurl-tab-1 episode  active fade in">
                                    <li><a href="httm=qssf"  >全球福利汇</a></li>
                                </ul>
                            </div>
                        </div>
                    </div> -->

                    <!-- 导航 结束 -->





                    <style>
                        .cpa {
                            display: none;
                        }

                        .cpa_item .icon {
                            display: block;
                            width: 45px;
                            height: 45px;
                            -webkit-transition: all .3s;
                            -moz-transition: all .3s;
                            -o-transition: all .3s;
                            transition: all .3s;
                        }

                        .cpa_item .icon img {
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                            border-radius: 5px;
                        }

                        .cpa_item .name {
                            width: 100%;
                            text-align: center;
                            margin-top: 8px;
                            overflow: hidden;
                            white-space: nowrap;
                            text-overflow: ellipsis;
                        }

                        .cpa_item {
                            width: 8%;
                            padding: 10px 5px;
                            font-size: 12px;
                            display: inline-flex;
                            flex-direction: column;
                            align-items: center;
                            transition: font-weight, background, transform .3s;
                        }

                        @media (max-width: 480px) {
                            .cpa_item {
                                width: 19%;
                                padding: 10px 5px;
                                font-size: 12px;
                                display: inline-flex;
                                flex-direction: column;
                                align-items: center;
                                transition: font-weight, background, transform .3s;
                            }

                            .cpa {
                                display: block;
                            }

                        }

                        .toplink {
                            border-radius: 0px 20px 20px 0px;
                            cursor: pointer;
                            display: inline-block;
                            border: 2px solid #4983ef;
                            color: white;
                            font-size: 14px;
                            padding: 2px 4px;
                            margin: 2px;
                            background: #002ec4;
                        }

                        .fontlink {
                            margin-left: 10px;
                            cursor: pointer;
                            display: inline-block;
                            border: 2px solid #fffd00;
                            color: white;
                            font-size: 18px;
                            padding: 2px 4px;
                            margin: 2px;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(1) {
                            color: #dc3545;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(2) {
                            color: #007bff;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(3) {
                            color: #28a745;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(4) {
                            color: #ffc107;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(5) {
                            color: #DB7093;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(6) {
                            color: #4169E1;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(7) {
                            color: #FFD700;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(8) {
                            color: #00CED1;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(9) {
                            color: #FF4500;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(10) {
                            color: #3CB371;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(11) {
                            color: #40E0D0;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(12) {
                            color: #1E90FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(13) {
                            color: #0000FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(14) {
                            color: #8A2BE2;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(15) {
                            color: #FF00FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(16) {
                            color: #6B8E23;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(17) {
                            color: #FF8C00;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(18) {
                            color: #A0522D;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(19) {
                            color: #B22222;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(20) {
                            color: #008080;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(21) {
                            color: #dc3545;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(22) {
                            color: #007bff;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(23) {
                            color: #28a745;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(24) {
                            color: #ffc107;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(25) {
                            color: #DB7093;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(26) {
                            color: #4169E1;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(27) {
                            color: #FFD700;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(28) {
                            color: #00CED1;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(29) {
                            color: #FF4500;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(30) {
                            color: #3CB371;
                            font-weight: bold;
                        }


                        .fontlink:nth-child(31) {
                            color: #40E0D0;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(32) {
                            color: #1E90FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(33) {
                            color: #0000FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(34) {
                            color: #8A2BE2;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(35) {
                            color: #FF00FF;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(36) {
                            color: #6B8E23;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(37) {
                            color: #FF8C00;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(38) {
                            color: #A0522D;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(39) {
                            color: #B22222;
                            font-weight: bold;
                        }

                        .fontlink:nth-child(40) {
                            color: #008080;
                            font-weight: bold;
                        }
                    </style>
                    <div class="container">
                        <section>
                            <div class="wrap">
                                <div class="block-text">

                                </div>
                        </section>
                    </div>
                    <div class="stui-pannel__head clearfix" style="margin-bottom: 0; margin-top: 10px;">
                        <h5 class="title">

                        </h5>
                    </div>


                    <div class="container">
<!--                         <section>
                            <div class="wrap">
                                <div class="block-text">

                                    <a href="https://饕餮.mengnanm.buzz/天天向上.html?from=qssf"  rel="nofollow" style="margin-left:10px;" class="fontlink">双马尾萝莉</a>
                                    <a href="https://饕餮.mengnanm.buzz/天天向上.html?from=qssf"  rel="nofollow" style="margin-left:10px;" class="fontlink">警花张津榆</a>




                                </div>
                            </div>
                        </section> -->

