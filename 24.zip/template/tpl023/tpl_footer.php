




<!--         <div class="tags">
            <a href="/video/search?q[title_cont]=高清" class="tag" >高清</a>
            <a href="/video/search?q[title_cont]=黄玫瑰" class="tag" >黄玫瑰</a>
        </div>

        <div class="foot_nav">
            <a href="/video/category/191" class="">国产视频</a>
            <a href="/video/category/195" class="">日韩无码</a>
        </div>


        <div class="content">

            <div class="new_foot_links" style="margin-top:20px;">
                <h2>合作伙伴</h2>

                <a class="jzhh" href="hn/"  style="">蓝导航</a>
                <a class="jzhh" href="http而后行/"  style="">AV集市</a>

            </div>
        </div> -->

        <div class="foot">
            <div class="logos">
                <a href="/"><img src="/template/{@var:cms_config_tpl_dir}/picture/logo-201.jpg"></a>
            </div>
            <p class="blkg">@
                Email: </p>
            <p>本站禁止兒童色情、暴力、違反美國律法等內容。僅對美籍華裔人士開放。禁止未成年人、當地法律不允許以及中國大陸地區等人群訪問。</p>
            <p>This site prohibits child pornography, violence, and content that violates US laws. Open to Chinese Americans only. Access by minors, those not allowed by local laws, and those in mainland China is prohibited.</p>
            <p>本站內容由程序自動採集，若有侵權，請立即聯繫刪除。</p>
            <p>The content of this site is automatically collected by the program. If there is any infringement, please contact us immediately to delete it.</p>
        </div>
    </div>



{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}