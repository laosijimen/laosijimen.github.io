<?php exit();?><!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <title>{@page_title}</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-type" name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">
        <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css?3">
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/search.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/common.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/base.js"></script>
        {@common_head}
    </head>
    
    <body ontouchstart="" style="">
        {@include file:header}

        <div class="wrap">
            <div class="main">
                <h1 id="titleH">{@name}</h1>

                <div class="torrent_content clearfix">
                    <div  class="clearfix" style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif;font-size: 16px;line-height: 1.5;color: #a3abc7;">
                        <!-- <p>【发布时间】：{@var:torrent_date}</p> -->

                        {base64}【影片格式】：{/base64}mp4<br>
                        {base64}【影片大小】：{/base64}{@var:torrent_size}<br>
                        {base64}【影片时长】：{/base64}{@var:torrent_duration}分钟<br>
                        {base64}【分辨率】：{/base64}{@var:torrent_resolution}<br>
                        {base64}【影片预览】：{/base64}<br>
                    </div>

                    <div class="clearfix" style="margin: 20px;">
                        {@var:torrent_capture}
                    </div>

                    <div style="clear: both;"></div>



<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }
  </script>

<style type="text/css">
   .wrapper {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;}
</style>

<div class="wrapper">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>


                    <div class="download clearfix" style="margin:20px 0; text-align: center;">
                        <span class="hide_mobile">
                            <a href='{@var:torrent_file_url}' target='_blank' class="down_btn">下载种子</a>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                        </span>
                        <a href='{@var:torrent_magnet}' class="down_btn">打开磁力</a>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <a onclick="copyText()" href="javascript:;" class="down_btn">复制磁力</a>
                    </div>



                    <div class="hide_mobile">
                      <a href='{@var:api_config_bt_client_pc_download_url}' target='_blank'>{@var:api_config_bt_client_pc_download_text}</a>
                    </div>

                    <div class="hide_pc">
                      <a href='{@var:api_config_bt_client_mobile_download_url}'>{@var:api_config_bt_client_mobile_download_text}</a>
                    </div>
                </div>
            </div>
        </div>
        <dir style="clear: both;"></dir>
        <div class="wrap">
            <div class="mod play-list">
                <div class="title">
                    <h3>猜你喜欢视频</h3></div>
                <div class="row col5 clearfix" id="cnxh">
                    {list type:bt mode:rand total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" title="">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt="" style="transition: all 1s ease 0s; opacity: 1;">
                                <i>
                                </i>
                            </a>
                        </dt>
                        <dd>
                            <a href="{_url}" title="">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>

                    {/list}


                </div>
            </div>
        </div>
        {@include file:footer}



    </body>
</html>