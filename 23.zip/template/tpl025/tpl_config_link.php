<?php exit();?>
link_top === 顶部链接 === 顶部链接