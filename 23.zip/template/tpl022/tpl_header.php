{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}

    <header class="header clearfix">
        <a href="/" class="navbar-brand header-logo"><img src="/template/{@var:cms_config_tpl_dir}/picture/logo.png"  style="height:100%;"></a>
    </header>


    <div class="mask2">
        <p class="headerChannelList2">
{nav type:video no:v2 count:8} 
            <a href="{_class_link}">{_class_name}</a>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
            <a href="{_class_link}">{_class_name}</a>
{/nav}


        </p>
    </div>


    <div id="link" class="block" style="background-color: #31efb6;">
        <ul>
{link area:link_dblj}
            <a class="text-sub-title mx-2 text-small" href="{_url}" target="_blank" style="margin:0 10px;">{base64}{_text}{/base64}</a>
{/link}
        </ul>
    </div>
    <div id="link" class="block" style="background-color: #31efb6;">
        <div class="stui-header__search">
            <form id="search" name="search" method="get" action="/search.php">
                <input type="text" id="wd" name="content" class="mac_wd form-control" value="" placeholder="请输入关键词...">
                <button class="submit" id="searchbutton" type="submit"></button>
            </form>
        </div>
    </div>

