<?php exit();?>
link_yqlj1 === 友情链接1 === 位于页面顶部
link_yqlj2 === 友情链接2 === 位于页面底部