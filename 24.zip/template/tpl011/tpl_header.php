    <section class="throughout">
        <div class="exclusive">
            
{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}


        </div>
    </section>

    <header>
        <div class="exclusive hangman">
            <div class="discharges"><a class="raunchy" href="/">
                    <h2>{@site_name}<span></span></h2>
                </a></div>
            <div id="menu_switcher" class="breasts">
                <i class="fa fa-bars" aria-hidden="true"></i>
            </div>
            <div class="iterate">
                <div class="through">
                    <form id="search_form">
                        <input class="begins" type="search" name="search_input" id="search_input" placeholder="搜索词..." autocomplete="off">
                        <button class="bondman"><i class="fas fa-search"></i></button>
                    </form>
                </div>
            </div>
            <div class="merciless">
                <div class="addthis_inline_share_toolbox_d75j"></div>
            </div>
        </div>
    </header>
    <section class="bisex">
        <div class="exclusive">
            <nav class="ploughs">
                <ul>
                    <li class=""><a href="/"><i class="fas fa-home"></i> 首页</a></li>


                    {nav type:video no:v2 count:8}
                    <li class="supplicate">|</li>
                    <li class=""><a href="{_class_link}"><i class="fas fa-play-circle"></i> {_class_name}</a></li>
                    {/nav}
                    {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                    <li class="supplicate">|</li>
                    <li class=""><a href="{_class_link}"><i class="fas fa-play-circle"></i> {_class_name}</a></li>
                    {/nav}



                </ul>
            </nav>
        </div>
    </section>
    <style>
        .block_app {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center
        }

        .block_app img {
            border-radius: 30%;
            width: 50px;
            height: 50px;
            object-fit: cover;
            border: 2px solid gray
        }

        .block_app_item {
            display: block;
            text-decoration: none;
        }

        .block_app_item_title {
            text-align: center;
            font-size: 14px;
            font-weight: 600;
            color: #E33A65
        }

        .block_app_item_image {
            margin: 13px
        }

        @media only screen and (max-width:768px) {
            .block_app img {
                width: 50px;
                height: 50px
            }

            .block_app_item_title {
                font-size: 12px
            }

            .block_app_item_image {
                margin: 5px
            }
        }
    </style>
    <style>
        /*.block_app{width:960px;margin:10px auto;}*/
        @media (max-width:960px) {
            .block_app {
                width: 96%
            }
        }
    </style>
<!--     <div class="block_app">
        <span class="">
            <a class="block_app_item ck_x" data-id="4183" href="https://發辦結艱.sejie8.de/懷鴿檻車檔" target="_blank" rel="nofollow">
                <img class="block_app_item_image lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" original="/upload/174435641.png">
                <div class="block_app_item_title">色界吧</div>
            </a>
        </span>
        <span class="">
            <a class="block_app_item ck_x" data-id="4180" href="https://ryd.fffqqq3.com/覇厥8旻-2148/" target="_blank" rel="nofollow">
                <img class="block_app_item_image lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" original="/upload/165934901.png">
                <div class="block_app_item_title">翻翻福利墙</div>
            </a>
        </span>
    </div> -->
    <style>
        .waibuurl {
            width: 100%;
            overflow: hidden;
            display: block;
            padding: 0;
            margin: 0;
        }

        .waibuurl span a {
            width: 9.78%;
            float: left;
            border-radius: 3px;
            line-height: 30px;
            height: 30px;
            text-align: center;
            font-size: 16px;
            color: #fff;
            display: inline-block;
            background-color: #df8888;
            margin: 1px;
            transition-duration: .3s;
            text-decoration: none;
        }

        .waibuurl span a:hover {
            background: #000000;
            color: #ffffff
        }

        @media screen and (max-width: 1000px) {
            .waibuurl span a {
                width: 32%;
                font-size: 12px;
            }
        }
    </style>
    <style>
        .resou {
            margin: 0 0 20px 0;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: flex-start
        }

        .resou li {
            margin: 2px;
            padding: 0;
            list-style: none
        }

        .resou li a {
            font-size: 18px;
            height: auto;
            line-height: inherit;
            padding: 0 3px;
            min-width: 36px;
            display: inline-block;
            border: 0;
            border-radius: 3px;
            box-sizing: border-box;
            background-color: #df8888;
            color: #fff;
            text-align: center;
            text-transform: uppercase;
            cursor: pointer;
            white-space: nowrap;
            text-decoration: none;
            line-height: 30px;
            height: 30px
        }
    </style>
    <div class="exclusive">
        <div class="waibuurl" style="margin-top: 5px;">
            <h2 class="ftitle">推荐导航</h2>
{link area:link_tjdh}
            <span class=""><a class="fen" href="{_url}" target="_blank" style="color:;" rel="nofollow">{base64}{_text}{/base64}</a></span>
{/link}
        </div>



        <h2 class="ftitle"><i class="fas fa-search"></i> 磁力搜索</h2>
        <ul class="resou">            
{splite var:search_tags_torrent}
<li class=""><a class="" href="/search.php?content=b64{_var_b64}&type=2"><i class="la la-search"></i> {base64}{_var}{/base64}</a></li>
{/splite}
        </ul>
    </div>