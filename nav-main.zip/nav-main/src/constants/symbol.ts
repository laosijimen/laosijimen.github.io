export const CODE_SYMBOL = '!'
export const SELF_SYMBOL = '^'
export const ROUTER_SYMBOL = '@'

export const DEFAULT_SORT_INDEX = 100000
