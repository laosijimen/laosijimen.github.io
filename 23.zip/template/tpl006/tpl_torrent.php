<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{@page_title}</title>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/jquery.fancybox-metal.css">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/fonts.css">

    <script data-cfasync="false" src="/template/{@var:cms_config_tpl_dir}/js/email-decode.min.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.cookie.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.form.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazy.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.scrollto.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.autocomplete.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.fancybox.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/main.min.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/main.js" type="text/javascript"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/rocket-loader.min.js"></script>


    <style>
        .block-post .item-post .name {
            white-space: inherit;
        }

        .header .nav li.active a {
            border-color: #FC0F64;
            color: #FC0F64;
            pointer-events: none;
        }

        @media (max-width: 1025px) {
            .m-panel .nav li.active a {
                border-color: #FC0F64;
                color: #FC0F64;
                pointer-events: none;
            }
        }

        main {
            max-width: 1344px;
            margin: 0 auto;
        }

        @media (max-width: 767.98px) {
            .m-panel .content {
                padding: 150px 20px 20px !important;
            }

            .m-panel .icon-close {
                padding: 300px 0 0 !important;
            }

            .m-panel .nav {
                display: inline-block;
            }

            .m-panel .nav li {
                width: 50%;
                float: left;
            }
        }
    </style>
    {@common_head}
</head>

<body>
    <div class="wrapper">
        {@include file:header}


<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }


var ua = navigator.userAgent.toLocaleLowerCase();
style=document.createElement('style');
if(ua.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian)/i)){
    var is_mobile=1;
    var is_pc=0;
    if(ua.match(/(ios|ipad|iphone)/i)){
        var is_ios = 1;
        var is_android = 0;
    }else{
        var is_ios = 0;
        var is_android = 1;
    }
    style.innerHTML = '.hide_mobile{display:none;}';
}else{
    var is_mobile=0;
    var is_pc=1;
    style.innerHTML = '.hide_pc{display:none;}';
}
document.getElementsByTagName('head')[0].appendChild(style);



    
  </script>

<style type="text/css">
   .wrapper {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;}
</style>

<div class="wrapper">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>

<style type="text/css">
.down_btn {
display: inline-block;
    border-radius: 5px;
    border: 1px solid #c48822;
    margin: 0px 6px 4px 0px;
    padding: 0px 5px;
    font-weight: bold;


    background: #FC0F64 !important;
    border-color: #FC0F64 !important;
    color: #fff !important;

    -webkit-transition: .3s;
    -o-transition: .3s;
    transition: .3s;

    position: relative;
    overflow: hidden;
    text-align: center;
    min-width: 60px;
    background: #1C1E29;
    border: none;
    color: #717383;
    font-weight: 700;
    -webkit-box-shadow: none;
    box-shadow: none;
    white-space: nowrap;
    font-size: 18px;
    border-radius: 10px;


}

.torrent_content{
    border-top: 1px solid rgba(255, 255, 255, .1);
    border-bottom: 1px solid rgba(255, 255, 255, .1);
    padding: 30px 20px;
    line-height: 40px;
    text-align: left;
    font-size: 18px;
}

.img_item {
    float: left;
}
@media (max-width: 500px) {
    .img_item{
        width: 50%;
    }
}
@media (min-width: 501px) {
    .img_item{
        width: 25%;
    }
}
.img_item{
    padding: 2px;
}
</style>


                <section class="section pt-30">
                    <div class="wrap">
                        <div class="title flex mix-filter">
                            <h2>{@name}</h2>
                        </div>
                            {base64}【影片格式】：mp4<br>
                            【影片大小】：{@var:torrent_size}<br>
                            【影片时长】：{@var:torrent_duration}分钟<br>
                            【分辨率】：{@var:torrent_resolution}<br>
                            【影片预览】：<br>{/base64}
                            {@var:torrent_capture}
                            <div style="clear:both;"></div>

                            <div>
                                <span class="hide_mobile"><a class="down_btn" href="{@var:torrent_file_url}">{base64}下载种子{/base64}</a></span>
                            

                            <a class="down_btn" href="{@var:torrent_magnet}">{base64}打开磁力{/base64}</a>

                            <a class="down_btn" onclick="copyText()" href="javascript:;">{base64}复制磁力{/base64}</a>
                            </div>

                    <div class="hide_mobile" style="padding-top: 40px;">
                      <a style="font-size: 16px; color: white;" href='{@var:api_config_bt_client_pc_download_url}' target='_blank'>{@var:api_config_bt_client_pc_download_text}</a>
                    </div>

                    <div class="hide_pc" style="padding-top: 40px;">
                      <a style="font-size: 16px; color: white;" href='{@var:api_config_bt_client_mobile_download_url}'>{@var:api_config_bt_client_mobile_download_text}</a>
                    </div>
                    </div>
                </section>

                <section class="section">
                    <div class="wrap">
                        <div class="title flex mix-filter">
                            <h2> 你可能喜欢的内容 </h2>
                        </div>
                        <div class="list-videos">
                            <div class="block-post flex">
                            {list type:bt mode:rand total:10 title_len:24}
                                <div class="item item-post">
                                    <a href="{_url}">
                                        <span class="img">
                                            <img class="lazy-load" src="/template/{@var:cms_config_tpl_dir}/picture/loading.gif" data-original="{_pic}" width="450" height="257" />
                                        </span>
                                        <h3 class="name">{_title}</h3>
                                    </a>
                                </div>
                            {/list}
                            </div>
                        </div>
                    </div>
                </section>

        {@include file:footer}
    </div>



</body>

</html>