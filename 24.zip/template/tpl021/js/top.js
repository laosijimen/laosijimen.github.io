document.writeln("<br>");
document.writeln("<a href=\"https://171775.app/p/IsAB\" target=\"_blank\"><img src=\"https://p.sda1.dev/16/0ba8a2a6cba8479bbf34789f15c4b1e8/960x80.gif\"/></a>");






