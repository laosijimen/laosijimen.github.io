



        <div class="friendTitle" id="friendTitle" style="">
                <h1 id="tuijianH1" style="">热门站点</h1>
        </div>
        <div class="group-box">
            <div class="group-contents layui-row bg-card">
{link area:link_rmzd}
<a target="_blank" href="{_url}" style="color:#fff !important;background:#3965aa !important;" class="mylink-y"  rel="nofollow">{base64}{_text}{/base64}</a>
{/link}
            </div>
            <br />

        </div>

        <div class="tags-box container">
            <div class="tags">
                <span class="tags-1 has-text-centered">
                    <div class="label2" id="biaoqian2">
{splite var:search_tags_video}
<a href="/search.php?content=b64{_var_b64}&type=1">{base64}{_var}{/base64}</a>
{/splite}

                    </div>
                </span>
            </div>
        </div>

        <div>
            <div class="return_top">
                <i class="layui-icon layui-icon-top"></i>
            </div>
        </div>
        <div class="bottom">

            <div class="wrap" style="text-align:center;">
                {base64}  
                邮箱联系：

                <br /> 警告：如果您當地法律許可之法定年齡本站歸類為限定為成年者已具有完整行為能力且願接受本站內影音內容、及各項條款之網友才可瀏覽！本站不存儲任何視頻資源，不提供資源的下載，本站資源均來自互聯網采集，僅供海外華人和個人學習使用。本站只適合十八歲或以上人士觀看, 本站內容可能令人反感；不可將此本站的內容派發，傳閱，出售，出租，交給或者 借予年齡未滿18歲的人士或將本網站內容向該人士出售，播放或放映，如果妳是該影片的版權方或所有者而要求刪除影片，我們僅提供采集的來源，並未享有刪除權利，請悉知！
                <p></p>
                <strong>Copyright &copy; 2020 - 2023 </strong>
                {/base64}
            </div>
        </div>



        <script>
            if (window.scrollY > 500) {
                document.querySelector(".return_top").style.display = 'block';
            }
            window.addEventListener("scroll", function() {
                var scroTop = window.scrollY;
                if (scroTop > 500) {
                    document.querySelector(".return_top").style.display = 'block';
                } else {
                    document.querySelector(".return_top").style.display = 'none';
                }
            });
            $('.return_top').click(function() {
                $("html,body").animate({
                    scrollTop: 0
                }, "fast");
            });
        </script>


{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}