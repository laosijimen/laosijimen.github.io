// 开源项目，未经作者同意，不得以抄袭/复制代码/修改源代码版权信息。
// Copyright @ 2018-present xiejiahe. All rights reserved.
// See https://github.com/xjh22222228/nav

export {}

declare global {
  const Swiper: any
  var __HASH_MODE__: boolean | undefined
  var __ADDRESS__: string | undefined
  var __FINISHED__: boolean // 记录已取 web 数据
  var __TITLE__: string = undefined
  var __PWA_ENABLE__: boolean | undefined
}
