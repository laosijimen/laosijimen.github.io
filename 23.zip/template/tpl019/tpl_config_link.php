<?php exit();?>
link_hzwz === 合作网站 === 