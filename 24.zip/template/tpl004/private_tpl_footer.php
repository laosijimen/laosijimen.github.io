<?php exit();?>
    <script>
        $("img.loadi").lazyload({
            effect: "fadeIn",
        });
        $("img.lazy").lazyload({
            effect: "fadeIn",
        });
    </script>

    <div class="container">
        <div class="content">
            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden">
                        <h4 class="mhlleset-title">友情链接</h4>
                    </div>
                    <div class="txtguanggao2">
                        <dl class="first">

                            {link area:youqinglianjie}
                            <dd>
                                <a href="{_url}" target="_blank" rel="nofollow" class="pd5">{base64}{_text}{/base64}</a>
                            </dd>
                            {/link}
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="content">
            <div class="footer">
                <div class="copyright">
                    <p><a href="/contact/" target="_blank" style="color: grey;">广告联系</a></p>
                </div>
            </div>
        </div>
    </div>


{ad area:dipiao}
{/ad}

{@site_tongji}

{ad area:js}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->