<?php exit();?>
link_tjhz === 推荐好站 === 导航下方
link_yqlj === 友情链接 === 页面底部