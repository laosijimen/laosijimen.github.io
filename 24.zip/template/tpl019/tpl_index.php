<html>

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,viewport-fit=cover,user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="referrer" content="always">
    <link href="/template/{@var:cms_config_tpl_dir}/css/home.css" rel="stylesheet" type="text/css" />
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.autocomplete.js"></script>
    <link href="/template/{@var:cms_config_tpl_dir}/css/layui.css" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="/template/{@var:cms_config_tpl_dir}/rose/css/style.cssx?_wd=false">
    <link id="layuicss-laydate" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/laydate.css" media="all">
    <link id="layuicss-layer" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/layer.css" media="all">
    <link id="layuicss-skincodecss" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/code.css" media="all">
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body style>
{@include file:header}
        <div class="group-box" style="background: rgba(202, 234, 203, 0.4);">
            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{@class_name type:video index:1}<a href="{@class_link type:video index:1}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:video index:1 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>


            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{@class_name type:video index:3}<a href="{@class_link type:video index:3}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:video index:3 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>

            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{@class_name type:video index:2}<a href="{@class_link type:video index:2}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:video index:2 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>

            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{@class_name type:video index:4}<a href="{@class_link type:video index:4}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:video index:4 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>

            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{base64}国产磁力{/base64}<a href="{@class_link type:bt index:1}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:bt index:1 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>


            <div class="group-contents layui-row">
                <div class="group-box" style="background: rgba(171, 219, 221, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-website"></i>&nbsp;&nbsp;{base64}日本磁力{/base64}<a href="{@class_link type:bt index:2}">&gt;&gt;更多</a></p>
                    <ul class="group-contents layui-row">
{list type:bt index:2 total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>

{@include file:footer}
</body>

</html>