<?php exit();?>
link_dblj === 顶部链接 === 顶部链接
link_rmzd === 热门站点 === 热门站点